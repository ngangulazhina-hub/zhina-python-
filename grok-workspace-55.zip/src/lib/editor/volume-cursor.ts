import type { EditorView } from "@codemirror/view";

const VOLUME_UP = new Set([
  "AudioVolumeUp",
  "VolumeUp",
  "MediaVolumeUp",
  "XF86AudioRaiseVolume",
  "AudioRaiseVolume",
]);
const VOLUME_DOWN = new Set([
  "AudioVolumeDown",
  "VolumeDown",
  "MediaVolumeDown",
  "XF86AudioLowerVolume",
  "AudioLowerVolume",
]);

export type CursorDir = "up" | "down" | "left" | "right";

export function isVolumeKey(e: KeyboardEvent): 1 | -1 | 0 {
  const key = e.key || "";
  const code = e.code || "";
  if (VOLUME_UP.has(key) || VOLUME_UP.has(code)) return 1;
  if (VOLUME_DOWN.has(key) || VOLUME_DOWN.has(code)) return -1;
  const kc = e.keyCode || e.which;
  // Android KEYCODE_VOLUME_UP/DOWN and legacy media keys
  if (kc === 24 || kc === 175 || kc === 183 || kc === 38 && e.altKey) return 1;
  if (kc === 25 || kc === 174 || kc === 182 || kc === 40 && e.altKey) return -1;
  if (key === "Unidentified") {
    if (kc === 24) return 1;
    if (kc === 25) return -1;
  }
  return 0;
}

export function moveCursor(view: EditorView, dir: CursorDir) {
  const head = view.state.selection.main.head;
  if (dir === "left" || dir === "right") {
    const next = dir === "left" ? Math.max(0, head - 1) : Math.min(view.state.doc.length, head + 1);
    view.dispatch({ selection: { anchor: next }, scrollIntoView: true });
    view.focus();
    return;
  }
  moveCursorLine(view, dir === "up" ? -1 : 1);
}

export function moveCursorLine(view: EditorView, direction: 1 | -1) {
  const head = view.state.selection.main.head;
  const line = view.state.doc.lineAt(head);
  const col = head - line.from;
  const nextNo = line.number + direction;
  if (nextNo < 1 || nextNo > view.state.doc.lines) return;
  const next = view.state.doc.line(nextNo);
  const pos = next.from + Math.min(col, next.length);
  view.dispatch({
    selection: { anchor: pos },
    scrollIntoView: true,
  });
  view.focus();
}

export function attachVolumeKeys(getView: () => EditorView | null, enabled: () => boolean) {
  const onKey = (e: Event) => {
    if (!enabled()) return;
    if (!(e instanceof KeyboardEvent)) return;
    if (e.type !== "keydown") return;
    const dir = isVolumeKey(e);
    if (!dir) return;
    const view = getView();
    if (!view) return;
    e.preventDefault();
    e.stopPropagation();
    moveCursorLine(view, dir === 1 ? -1 : 1);
  };
  window.addEventListener("keydown", onKey, { capture: true });
  return () => {
    window.removeEventListener("keydown", onKey, { capture: true });
  };
}
