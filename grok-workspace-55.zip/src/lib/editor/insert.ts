import { EditorView } from "@codemirror/view";
import { indentMore, indentLess, undo, redo } from "@codemirror/commands";

const PAIRS: Record<string, string> = {
  "(": ")",
  "[": "]",
  "{": "}",
  '"': '"',
  "'": "'",
  "`": "`",
  'f"': '"',
};

function insertIntoField(el: HTMLInputElement | HTMLTextAreaElement, text: string) {
  const close = PAIRS[text] ?? "";
  const start = el.selectionStart ?? el.value.length;
  const end = el.selectionEnd ?? start;
  const selected = el.value.slice(start, end);
  const chunk = close && selected ? `${text}${selected}${close}` : close ? `${text}${close}` : text;
  const next = el.value.slice(0, start) + chunk + el.value.slice(end);
  el.value = next;
  const caret = start + (close && !selected ? text.length : chunk.length);
  el.setSelectionRange(caret, caret);
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.focus();
}

export function insertText(view: EditorView | null, text: string) {
  const active = document.activeElement;
  if (active instanceof HTMLInputElement || active instanceof HTMLTextAreaElement) {
    insertIntoField(active, text);
    return;
  }
  if (!view) return;
  const close = PAIRS[text];
  const sel = view.state.selection.main;
  if (close && sel.from !== sel.to) {
    const chosen = view.state.sliceDoc(sel.from, sel.to);
    const wrapped = `${text}${chosen}${close}`;
    view.dispatch({
      changes: { from: sel.from, to: sel.to, insert: wrapped },
      selection: { anchor: sel.from + wrapped.length },
      scrollIntoView: true,
    });
  } else if (close) {
    view.dispatch({
      changes: { from: sel.from, to: sel.to, insert: text + close },
      selection: { anchor: sel.from + text.length },
      scrollIntoView: true,
    });
  } else {
    view.dispatch({
      changes: { from: sel.from, to: sel.to, insert: text },
      selection: { anchor: sel.from + text.length },
      scrollIntoView: true,
    });
  }
  view.focus();
}

export function runEditorCommand(view: EditorView | null, name: "tab" | "untab" | "undo" | "redo") {
  if (!view) return;
  const cmd = name === "tab" ? indentMore : name === "untab" ? indentLess : name === "undo" ? undo : redo;
  cmd(view);
  view.focus();
}
