import { useEffect, useState } from "react";

export function readKeyboardInset() {
  if (typeof window === "undefined") return 0;
  const vv = window.visualViewport;
  if (!vv) return 0;
  const inset = Math.max(0, window.innerHeight - vv.height - vv.offsetTop);
  return inset > 40 ? Math.round(inset) : 0;
}

export function useKeyboardInset() {
  const [inset, setInset] = useState(0);

  useEffect(() => {
    const apply = () => {
      const next = readKeyboardInset();
      setInset(next);
      document.documentElement.style.setProperty("--zhina-kb", `${next}px`);
    };
    apply();
    const vv = window.visualViewport;
    vv?.addEventListener("resize", apply);
    vv?.addEventListener("scroll", apply);
    window.addEventListener("resize", apply);
    window.addEventListener("focusin", apply);
    window.addEventListener("focusout", apply);
    return () => {
      vv?.removeEventListener("resize", apply);
      vv?.removeEventListener("scroll", apply);
      window.removeEventListener("resize", apply);
      window.removeEventListener("focusin", apply);
      window.removeEventListener("focusout", apply);
    };
  }, []);

  return inset;
}
