import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { WELCOME_CODE } from "@/lib/ide/examples";
import { THEME_PRESETS, type EditorColors, type ThemePreset } from "@/lib/ide/themes";
import type { Diagnostic, RuntimeStatus, TerminalLine } from "@/lib/python/types";
import type { ParsedError } from "@/lib/python/traceback";

export type Screen = "editor" | "terminal" | "settings" | "libraries";
export type TerminalLayout = "below" | "screen";

export type IdeFile = {
  id: string;
  name: string;
  code: string;
  updatedAt: number;
};

export type IdeSettings = EditorColors & {
  preset: ThemePreset;
  fontFamily: string;
  fontSize: number;
  fontWeight: "400" | "500" | "600" | "700";
  fontStyle: "normal" | "italic";
  tabSize: number;
  wordWrap: boolean;
  showBlockLines: boolean;
  volumeCursor: boolean;
};

const ink = THEME_PRESETS.ink.colors;

export const DEFAULT_SETTINGS: IdeSettings = {
  ...ink,
  preset: "ink",
  fontFamily: "IBM Plex Mono",
  fontSize: 14,
  fontWeight: "400",
  fontStyle: "normal",
  tabSize: 4,
  wordWrap: true,
  showBlockLines: true,
  volumeCursor: true,
};

export const WELCOME_FILE: IdeFile = {
  id: "welcome",
  name: "welcome.py",
  code: WELCOME_CODE,
  updatedAt: 0,
};

function uid() {
  return `f${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
}

function untitledName(files: IdeFile[]) {
  const used = new Set(files.map((f) => f.name.toLowerCase()));
  if (!used.has("untitled.py")) return "untitled.py";
  let n = 2;
  while (used.has(`untitled${n}.py`)) n += 1;
  return `untitled${n}.py`;
}

type IdeState = {
  hydrated: boolean;
  hasUsed: boolean;
  files: IdeFile[];
  activeFileId: string;
  code: string;
  stdin: string;
  replDraft: string;
  settings: IdeSettings;
  terminalLayout: TerminalLayout;
  screen: Screen;
  status: RuntimeStatus;
  statusDetail: string;
  pythonVersion: string;
  lines: TerminalLine[];
  diagnostics: Diagnostic[];
  lastError: ParsedError | null;
  cursor: { line: number; column: number };
  persistGranted: boolean;
  hintDismissed: boolean;
  setHydrated: () => void;
  setCode: (code: string) => void;
  setStdin: (stdin: string) => void;
  setReplDraft: (v: string) => void;
  patchSettings: (patch: Partial<IdeSettings>) => void;
  applyPreset: (preset: ThemePreset) => void;
  setTerminalLayout: (layout: TerminalLayout) => void;
  setScreen: (screen: Screen) => void;
  setStatus: (status: RuntimeStatus, detail?: string) => void;
  setPythonVersion: (v: string) => void;
  appendLine: (line: Omit<TerminalLine, "id">) => void;
  clearTerminal: () => void;
  setDiagnostics: (d: Diagnostic[]) => void;
  setLastError: (e: ParsedError | null) => void;
  setCursor: (line: number, column: number) => void;
  setPersistGranted: (v: boolean) => void;
  dismissHint: () => void;
  resetSettings: () => void;
  newFile: (name?: string, code?: string) => void;
  openFile: (id: string) => void;
  closeFile: (id: string) => void;
  renameFile: (id: string, name: string) => void;
  upsertNamedFile: (name: string, code: string) => void;
};

let lineSeq = 0;

function syncActive(files: IdeFile[], activeFileId: string, extra: Partial<IdeState> = {}): Partial<IdeState> {
  const active = files.find((f) => f.id === activeFileId) ?? files[0];
  return {
    files,
    activeFileId: active?.id ?? WELCOME_FILE.id,
    code: active?.code ?? "",
    ...extra,
  };
}

export const useIdeStore = create<IdeState>()(
  persist(
    (set) => ({
      hydrated: false,
      hasUsed: false,
      files: [WELCOME_FILE],
      activeFileId: WELCOME_FILE.id,
      code: WELCOME_CODE,
      stdin: "",
      replDraft: "",
      settings: DEFAULT_SETTINGS,
      terminalLayout: "below",
      screen: "editor",
      status: "idle",
      statusDetail: "",
      pythonVersion: "Python 3.14",
      lines: [],
      diagnostics: [],
      lastError: null,
      cursor: { line: 1, column: 1 },
      persistGranted: false,
      hintDismissed: false,
      setHydrated: () => set({ hydrated: true }),
      setCode: (code) =>
        set((s) => {
          const files = s.files.map((f) =>
            f.id === s.activeFileId ? { ...f, code, updatedAt: Date.now() } : f,
          );
          return { code, hasUsed: true, files };
        }),
      setStdin: (stdin) => set({ stdin }),
      setReplDraft: (replDraft) => set({ replDraft }),
      patchSettings: (patch) => set((s) => ({ settings: { ...s.settings, ...patch } })),
      applyPreset: (preset) =>
        set((s) => ({
          settings: { ...s.settings, ...THEME_PRESETS[preset].colors, preset },
        })),
      setTerminalLayout: (terminalLayout) =>
        set((s) => ({
          terminalLayout,
          screen: terminalLayout === "screen" && s.screen === "terminal" ? "terminal" : "editor",
        })),
      setScreen: (screen) => set({ screen }),
      setStatus: (status, statusDetail = "") => set({ status, statusDetail }),
      setPythonVersion: (pythonVersion) => set({ pythonVersion }),
      appendLine: (line) =>
        set((s) => ({
          lines: [...s.lines, { ...line, id: `l${++lineSeq}` }].slice(-400),
        })),
      clearTerminal: () => set({ lines: [], lastError: null }),
      setDiagnostics: (diagnostics) => set({ diagnostics }),
      setLastError: (lastError) => set({ lastError }),
      setCursor: (line, column) => set({ cursor: { line, column } }),
      setPersistGranted: (persistGranted) => set({ persistGranted }),
      dismissHint: () => set({ hintDismissed: true }),
      resetSettings: () => set({ settings: DEFAULT_SETTINGS, terminalLayout: "below" }),
      newFile: (name, code = "") =>
        set((s) => {
          const file: IdeFile = {
            id: uid(),
            name: name?.trim() || untitledName(s.files),
            code,
            updatedAt: Date.now(),
          };
          return syncActive([file, ...s.files], file.id, { hasUsed: true, lastError: null });
        }),
      openFile: (id) =>
        set((s) => {
          const file = s.files.find((f) => f.id === id);
          if (!file) return {};
          const rest = s.files.filter((f) => f.id !== id);
          return syncActive([{ ...file, updatedAt: Date.now() }, ...rest], id);
        }),
      closeFile: (id) =>
        set((s) => {
          if (s.files.length <= 1) {
            const only = { ...WELCOME_FILE, id: uid(), updatedAt: Date.now() };
            return syncActive([only], only.id, { hasUsed: true, lastError: null });
          }
          const files = s.files.filter((f) => f.id !== id);
          const nextId = s.activeFileId === id ? (files[0]?.id ?? WELCOME_FILE.id) : s.activeFileId;
          return syncActive(files, nextId, s.activeFileId === id ? { lastError: null } : {});
        }),
      renameFile: (id, name) =>
        set((s) => {
          const trimmed = name.trim() || "untitled.py";
          const withExt = trimmed.endsWith(".py") ? trimmed : `${trimmed}.py`;
          return {
            files: s.files.map((f) => (f.id === id ? { ...f, name: withExt, updatedAt: Date.now() } : f)),
          };
        }),
      upsertNamedFile: (name, code) =>
        set((s) => {
          const existing = s.files.find((f) => f.name.toLowerCase() === name.toLowerCase());
          if (existing) {
            const files = s.files.map((f) =>
              f.id === existing.id ? { ...f, code, updatedAt: Date.now() } : f,
            );
            return syncActive(files, existing.id, { hasUsed: true });
          }
          const file: IdeFile = { id: uid(), name, code, updatedAt: Date.now() };
          return syncActive([file, ...s.files], file.id, { hasUsed: true });
        }),
    }),
    {
      name: "zhina-python",
      version: 2,
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      partialize: (s) => ({
        code: s.code,
        stdin: s.stdin,
        settings: s.settings,
        terminalLayout: s.terminalLayout,
        hasUsed: s.hasUsed,
        hintDismissed: s.hintDismissed,
        files: s.files,
        activeFileId: s.activeFileId,
      }),
      migrate: (persisted, version) => {
        const s = persisted as Partial<IdeState> & { code?: string };
        if (version < 2 || !Array.isArray(s.files) || s.files.length === 0) {
          const code = typeof s.code === "string" && s.code.length ? s.code : WELCOME_CODE;
          const file: IdeFile = {
            id: "welcome",
            name: "welcome.py",
            code,
            updatedAt: Date.now(),
          };
          return { ...s, files: [file], activeFileId: file.id, code };
        }
        const active = s.files.find((f) => f.id === s.activeFileId) ?? s.files[0];
        return { ...s, code: active?.code ?? s.code ?? WELCOME_CODE, activeFileId: active?.id };
      },
    },
  ),
);

export function activeFile(state: Pick<IdeState, "files" | "activeFileId">) {
  return state.files.find((f) => f.id === state.activeFileId) ?? state.files[0] ?? WELCOME_FILE;
}
