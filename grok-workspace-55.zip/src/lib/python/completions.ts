import {
  type Completion,
  type CompletionContext,
  autocompletion,
  snippetCompletion,
} from "@codemirror/autocomplete";

const KEYWORDS: Completion[] = [
  "False",
  "None",
  "True",
  "and",
  "as",
  "assert",
  "async",
  "await",
  "break",
  "continue",
  "del",
  "elif",
  "else",
  "except",
  "finally",
  "from",
  "global",
  "import",
  "in",
  "is",
  "lambda",
  "nonlocal",
  "not",
  "or",
  "pass",
  "raise",
  "return",
  "yield",
].map((label) => ({ label, type: "keyword", boost: 20 }));

const BUILTINS: Completion[] = [
  "abs",
  "all",
  "any",
  "ascii",
  "bin",
  "bool",
  "bytearray",
  "bytes",
  "callable",
  "chr",
  "classmethod",
  "compile",
  "complex",
  "dict",
  "dir",
  "divmod",
  "enumerate",
  "eval",
  "exec",
  "filter",
  "float",
  "format",
  "frozenset",
  "getattr",
  "globals",
  "hasattr",
  "hash",
  "help",
  "hex",
  "id",
  "input",
  "int",
  "isinstance",
  "issubclass",
  "iter",
  "len",
  "list",
  "locals",
  "map",
  "max",
  "min",
  "next",
  "object",
  "oct",
  "open",
  "ord",
  "pow",
  "print",
  "property",
  "range",
  "repr",
  "reversed",
  "round",
  "set",
  "setattr",
  "slice",
  "sorted",
  "staticmethod",
  "str",
  "sum",
  "super",
  "tuple",
  "type",
  "vars",
  "zip",
].map((label) => ({
  label,
  type: "function",
  boost: label === "print" || label === "len" || label === "range" || label === "input" ? 50 : 10,
}));

const MODULES: Completion[] = [
  "math",
  "random",
  "statistics",
  "datetime",
  "time",
  "json",
  "re",
  "os",
  "sys",
  "pathlib",
  "collections",
  "itertools",
  "functools",
  "typing",
  "dataclasses",
  "csv",
  "io",
  "base64",
  "hashlib",
  "decimal",
  "fractions",
  "pprint",
  "unittest",
  "traceback",
  "ast",
  "numpy",
  "pandas",
  "matplotlib",
  "matplotlib.pyplot",
  "scipy",
  "sklearn",
  "PIL",
  "sympy",
  "networkx",
].map((label) => ({ label, type: "namespace", boost: 15 }));

const SNIPPETS: Completion[] = [
  snippetCompletion("def ${name}(${args}):\n    ${pass}", {
    label: "def",
    type: "keyword",
    detail: "function",
    boost: 80,
  }),
  snippetCompletion("class ${Name}:\n    def __init__(self):\n        ${pass}", {
    label: "class",
    type: "keyword",
    detail: "class",
    boost: 70,
  }),
  snippetCompletion("if ${condition}:\n    ${pass}", { label: "if", type: "keyword", boost: 70 }),
  snippetCompletion("elif ${condition}:\n    ${pass}", { label: "elif", type: "keyword", boost: 40 }),
  snippetCompletion("for ${item} in ${iterable}:\n    ${pass}", { label: "for", type: "keyword", boost: 70 }),
  snippetCompletion("while ${condition}:\n    ${pass}", { label: "while", type: "keyword", boost: 70 }),
  snippetCompletion("try:\n    ${pass}\nexcept ${Exception} as ${exc}:\n    ${raise}", {
    label: "try",
    type: "keyword",
    boost: 60,
  }),
  snippetCompletion("with ${expr} as ${name}:\n    ${pass}", { label: "with", type: "keyword", boost: 50 }),
  snippetCompletion('if __name__ == "__main__":\n    ${main()}', {
    label: "main",
    type: "snippet",
    detail: "entrypoint",
    boost: 40,
  }),
  snippetCompletion("print(${value})", { label: "print()", type: "function", boost: 90 }),
  snippetCompletion("input(${prompt})", { label: "input()", type: "function", boost: 60 }),
];

const MEMBERS: Record<string, string[]> = {
  math: ["sqrt", "sin", "cos", "tan", "pi", "e", "floor", "ceil", "log", "log10", "exp", "pow", "radians", "degrees", "fabs"],
  random: ["random", "randint", "choice", "shuffle", "sample", "seed", "uniform", "gauss", "randrange"],
  json: ["loads", "dumps", "load", "dump"],
  re: ["compile", "search", "match", "findall", "sub", "split", "fullmatch"],
  os: ["path", "getcwd", "listdir", "environ", "name"],
  sys: ["version", "argv", "path", "platform", "exit", "stdin", "stdout", "stderr"],
  time: ["sleep", "time", "strftime", "localtime"],
  datetime: ["datetime", "date", "time", "timedelta"],
  np: ["array", "arange", "linspace", "zeros", "ones", "dot", "mean", "sum", "shape", "reshape", "concatenate"],
  numpy: ["array", "arange", "linspace", "zeros", "ones", "dot", "mean"],
  pd: ["DataFrame", "Series", "read_csv", "concat", "to_csv"],
  pandas: ["DataFrame", "Series", "read_csv", "concat"],
  plt: ["plot", "scatter", "bar", "hist", "show", "title", "xlabel", "ylabel", "legend", "subplots", "tight_layout", "savefig"],
  str: ["split", "join", "strip", "replace", "format", "lower", "upper", "startswith", "endswith", "find"],
  list: ["append", "extend", "pop", "sort", "reverse", "index", "count", "insert", "remove"],
  dict: ["get", "keys", "values", "items", "update", "pop", "setdefault"],
};

function identifiersIn(doc: string): Completion[] {
  const found = new Set<string>();
  for (const m of doc.matchAll(/^\s*(?:async\s+)?def\s+([A-Za-z_]\w*)/gm)) {
    if (m[1]) found.add(m[1]);
  }
  for (const m of doc.matchAll(/^\s*class\s+([A-Za-z_]\w*)/gm)) {
    if (m[1]) found.add(m[1]);
  }
  for (const m of doc.matchAll(/^\s*([A-Za-z_]\w*)\s*=/gm)) {
    if (m[1]) found.add(m[1]);
  }
  return [...found].map((label) => ({ label, type: "variable", boost: 30 }));
}

function matches(label: string, query: string) {
  if (!query) return true;
  const l = label.toLowerCase();
  const q = query.toLowerCase();
  return l.startsWith(q) || l.includes(q);
}

function pythonCompletions(context: CompletionContext) {
  const importBefore = context.matchBefore(/(?:from|import)\s+[\w.]*$/);
  if (importBefore) {
    const start = importBefore.from + importBefore.text.search(/[\w.]+$/);
    const typed = importBefore.text.match(/[\w.]+$/)?.[0] ?? "";
    return {
      from: start < 0 ? importBefore.to : start,
      options: MODULES.filter((m) => matches(m.label, typed)),
      validFor: /^[\w.]*$/,
      filter: false,
    };
  }

  const dotted = context.matchBefore(/[A-Za-z_][\w]*\.\w*$/);
  if (dotted) {
    const parts = dotted.text.split(".");
    const obj = parts[0] ?? "";
    const partial = parts.slice(1).join(".");
    const members = MEMBERS[obj] ?? [];
    return {
      from: dotted.from + obj.length + 1,
      options: members
        .filter((m) => matches(m, partial))
        .map((label) => ({ label, type: "property" as const, boost: 40 })),
      validFor: /^\w*$/,
      filter: false,
    };
  }

  const word = context.matchBefore(/[A-Za-z_]\w*/);
  if (!word) {
    if (context.explicit) {
      return { from: context.pos, options: [...SNIPPETS, ...KEYWORDS, ...BUILTINS], filter: false };
    }
    return null;
  }
  if (word.from === word.to && !context.explicit) return null;

  const q = word.text;
  const local = identifiersIn(context.state.doc.toString());
  const options = [...SNIPPETS, ...KEYWORDS, ...BUILTINS, ...MODULES, ...local].filter((o) =>
    matches(o.label, q),
  );

  if (!options.length && !context.explicit) return null;

  return {
    from: word.from,
    options,
    validFor: /^\w*$/,
    filter: false,
  };
}

export function pythonAutocomplete() {
  return autocompletion({
    override: [pythonCompletions],
    defaultKeymap: true,
    activateOnTyping: true,
    activateOnTypingDelay: 40,
    closeOnBlur: false,
    icons: true,
    tooltipClass: () => "zhina-complete",
    optionClass: () => "zhina-complete-item",
    maxRenderedOptions: 12,
  });
}
