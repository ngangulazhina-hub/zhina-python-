import { Book, Download, FolderOpen, Menu, Plus, Settings, Terminal, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { EXAMPLES } from "@/lib/ide/examples";
import { useIdeStore } from "@/lib/ide/store";
import { useState } from "react";
import { createPortal } from "react-dom";

export function IdeHeader() {
  const setScreen = useIdeStore((s) => s.setScreen);
  const upsertNamedFile = useIdeStore((s) => s.upsertNamedFile);
  const layout = useIdeStore((s) => s.terminalLayout);
  const screen = useIdeStore((s) => s.screen);
  const [menu, setMenu] = useState(false);
  const [examples, setExamples] = useState(false);

  const openFile = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".py,text/x-python,text/plain";
    input.onchange = () => {
      const file = input.files?.[0];
      if (!file) return;
      void file.text().then((text) => upsertNamedFile(file.name || "upload.py", text));
    };
    input.click();
  };

  const saveFile = () => {
    const state = useIdeStore.getState();
    const current = state.files.find((f) => f.id === state.activeFileId);
    const blob = new Blob([state.code], { type: "text/x-python" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = current?.name || "main.py";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <header className="relative z-50 flex h-12 shrink-0 items-center gap-1 border-b border-border bg-bg px-2 pt-[env(safe-area-inset-top)]">
      <div className="flex min-w-0 flex-1 items-center gap-2 pl-1">
        <Logo />
        <div className="min-w-0">
          <p className="truncate text-sm font-medium tracking-tight">Zhina</p>
          <p className="truncate text-[11px] text-muted">Python</p>
        </div>
      </div>
      {layout === "screen" ? (
        <div className="mr-1 flex rounded-lg bg-elevated p-0.5">
          <button
            type="button"
            className={`h-8 rounded-md px-3 text-xs ${screen === "editor" ? "bg-surface text-fg" : "text-muted"}`}
            onClick={() => setScreen("editor")}
          >
            Code
          </button>
          <button
            type="button"
            className={`h-8 rounded-md px-3 text-xs ${screen === "terminal" ? "bg-surface text-fg" : "text-muted"}`}
            onClick={() => setScreen("terminal")}
          >
            Output
          </button>
        </div>
      ) : null}
      <Button
        type="button"
        variant="ghost"
        size="sm"
        className="hidden h-10 px-2 sm:inline-flex"
        onClick={() => setExamples(true)}
      >
        <Book className="size-4" />
        Examples
      </Button>
      <Button type="button" variant="ghost" size="icon" className="size-11 sm:hidden" aria-label="Examples" onClick={() => setExamples(true)}>
        <Book className="size-5" />
      </Button>
      <Button type="button" variant="ghost" size="icon" className="size-11" aria-label="Menu" onClick={() => setMenu(true)}>
        <Menu className="size-5" />
      </Button>
      <Button type="button" variant="ghost" size="icon" className="size-11" aria-label="Settings" onClick={() => setScreen("settings")}>
        <Settings className="size-5" />
      </Button>

      {examples
        ? createPortal(
            <Sheet title="Examples" onClose={() => setExamples(false)}>
              {EXAMPLES.map((ex) => (
                <button
                  key={ex.id}
                  type="button"
                  className="flex min-h-12 w-full items-center rounded-xl px-4 text-left text-sm hover:bg-elevated"
                  onClick={() => {
                    upsertNamedFile(`${ex.id}.py`, ex.code);
                    setExamples(false);
                    setScreen("editor");
                  }}
                >
                  {ex.title}
                </button>
              ))}
            </Sheet>,
            document.body,
          )
        : null}

      {menu
        ? createPortal(
            <Sheet title="Menu" onClose={() => setMenu(false)}>
              <Item
                icon={<Plus className="size-4" />}
                label="New file"
                onClick={() => {
                  useIdeStore.getState().newFile();
                  setMenu(false);
                }}
              />
              <Item
                icon={<FolderOpen className="size-4" />}
                label="Open .py file"
                onClick={() => {
                  openFile();
                  setMenu(false);
                }}
              />
              <Item
                icon={<Download className="size-4" />}
                label="Download .py"
                onClick={() => {
                  saveFile();
                  setMenu(false);
                }}
              />
              <Item
                icon={<Book className="size-4" />}
                label="Libraries"
                onClick={() => {
                  setScreen("libraries");
                  setMenu(false);
                }}
              />
              <Item
                icon={<Terminal className="size-4" />}
                label={layout === "below" ? "Terminal on its own screen" : "Terminal under editor"}
                onClick={() => {
                  useIdeStore.getState().setTerminalLayout(layout === "below" ? "screen" : "below");
                  setMenu(false);
                }}
              />
              <Item
                icon={<Settings className="size-4" />}
                label="Settings"
                onClick={() => {
                  setScreen("settings");
                  setMenu(false);
                }}
              />
            </Sheet>,
            document.body,
          )
        : null}
    </header>
  );
}

function Item({ icon, label, onClick }: { icon: React.ReactNode; label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      className="flex min-h-12 w-full items-center gap-3 rounded-xl px-4 text-left text-sm hover:bg-elevated"
      onClick={onClick}
    >
      {icon}
      {label}
    </button>
  );
}

function Sheet({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <div className="fixed inset-0 z-[80] flex items-end justify-center sm:items-center">
      <button type="button" className="absolute inset-0 bg-bg/70" aria-label="Close" onClick={onClose} />
      <div className="relative mb-0 w-full max-w-md rounded-t-3xl bg-surface p-3 pb-[max(1rem,env(safe-area-inset-bottom))] shadow-[var(--shadow-lift)] sm:mb-8 sm:rounded-3xl">
        <div className="mb-2 flex items-center justify-between px-2">
          <h2 className="text-base font-medium">{title}</h2>
          <Button type="button" variant="ghost" size="icon" className="size-10" aria-label="Close" onClick={onClose}>
            <X className="size-4" />
          </Button>
        </div>
        <div className="max-h-[70dvh] overflow-auto">{children}</div>
      </div>
    </div>
  );
}

function Logo() {
  return (
    <svg width="28" height="28" viewBox="0 0 28 28" aria-hidden className="shrink-0">
      <rect width="28" height="28" rx="7" fill="currentColor" className="text-accent" />
      <path d="M8 8h12l-8 6 8 6H8" fill="none" stroke="currentColor" className="text-accent-fg" strokeWidth="2.1" strokeLinejoin="round" />
    </svg>
  );
}
