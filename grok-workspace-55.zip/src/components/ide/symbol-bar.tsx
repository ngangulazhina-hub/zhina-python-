import type { EditorView } from "@codemirror/view";
import { ChevronLeft, ChevronRight, Delete, Redo2, Undo2 } from "lucide-react";
import { insertText, runEditorCommand } from "@/lib/editor/insert";
import { moveCursor } from "@/lib/editor/volume-cursor";
import { startCompletion } from "@codemirror/autocomplete";
import { cn } from "@/lib/utils";

type KeySpec =
  | { kind: "text"; label: string; insert: string; wide?: boolean }
  | { kind: "cmd"; label: string; cmd: "tab" | "untab" | "undo" | "redo"; wide?: boolean }
  | { kind: "move"; label: string; dir: "left" | "right" }
  | { kind: "complete" }
  | { kind: "backspace" };

const KEYS: KeySpec[] = [
  { kind: "cmd", label: "Tab", cmd: "tab", wide: true },
  { kind: "text", label: "(", insert: "(" },
  { kind: "text", label: ")", insert: ")" },
  { kind: "text", label: "[", insert: "[" },
  { kind: "text", label: "]", insert: "]" },
  { kind: "text", label: "{", insert: "{" },
  { kind: "text", label: "}", insert: "}" },
  { kind: "text", label: '"', insert: '"' },
  { kind: "text", label: "'", insert: "'" },
  { kind: "text", label: ":", insert: ":" },
  { kind: "text", label: ",", insert: "," },
  { kind: "text", label: ".", insert: "." },
  { kind: "text", label: "=", insert: "=" },
  { kind: "text", label: "+", insert: "+" },
  { kind: "text", label: "-", insert: "-" },
  { kind: "text", label: "*", insert: "*" },
  { kind: "text", label: "/", insert: "/" },
  { kind: "text", label: "#", insert: "#" },
  { kind: "text", label: "_", insert: "_" },
  { kind: "text", label: "\\", insert: "\\" },
  { kind: "text", label: "<", insert: "<" },
  { kind: "text", label: ">", insert: ">" },
  { kind: "text", label: "->", insert: " -> " },
  { kind: "text", label: "f\"", insert: 'f"' },
  { kind: "complete" },
  { kind: "cmd", label: "undo", cmd: "undo" },
  { kind: "cmd", label: "redo", cmd: "redo" },
  { kind: "move", label: "left", dir: "left" },
  { kind: "move", label: "right", dir: "right" },
  { kind: "backspace" },
];

export function SymbolBar({
  viewRef,
  keyboardInset = 0,
}: {
  viewRef: React.MutableRefObject<EditorView | null>;
  keyboardInset?: number;
}) {
  const press = (action: () => void) => (e: React.PointerEvent) => {
    e.preventDefault();
    action();
  };

  const run = (spec: KeySpec) => {
    const view = viewRef.current;
    if (spec.kind === "text") {
      insertText(view, spec.insert);
      return;
    }
    if (!view) return;
    if (spec.kind === "cmd") runEditorCommand(view, spec.cmd);
    else if (spec.kind === "move") moveCursor(view, spec.dir);
    else if (spec.kind === "complete") {
      startCompletion(view);
      view.focus();
    } else if (spec.kind === "backspace") {
      const sel = view.state.selection.main;
      const from = sel.from === sel.to ? Math.max(0, sel.from - 1) : sel.from;
      view.dispatch({
        changes: { from, to: sel.to },
        selection: { anchor: from },
        scrollIntoView: true,
      });
      view.focus();
    }
  };

  return (
    <div
      className="z-30 flex min-h-[52px] shrink-0 items-center gap-1 overflow-x-auto border-t border-border bg-surface px-1.5 touch-manipulation [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
      style={{ paddingBottom: keyboardInset > 0 ? 0 : "env(safe-area-inset-bottom)" }}
      aria-label="Coding keys"
    >
      {KEYS.map((key) => (
        <button
          key={key.kind === "text" ? `t-${key.label}` : key.kind === "cmd" ? `c-${key.cmd}` : key.kind === "move" ? `m-${key.dir}` : key.kind}
          type="button"
          className={cn(
            "flex h-10 shrink-0 items-center justify-center rounded-lg bg-elevated font-mono text-sm text-fg active:bg-accent active:text-accent-fg",
            key.kind === "cmd" && key.wide ? "min-w-12 px-2.5 text-xs" : "min-w-10",
            key.kind === "complete" ? "min-w-14 px-2 text-xs" : "",
          )}
          aria-label={ariaFor(key)}
          onPointerDown={press(() => run(key))}
        >
          {labelFor(key)}
        </button>
      ))}
    </div>
  );
}

function labelFor(key: KeySpec) {
  if (key.kind === "cmd" && key.cmd === "undo") return <Undo2 className="size-4" />;
  if (key.kind === "cmd" && key.cmd === "redo") return <Redo2 className="size-4" />;
  if (key.kind === "move" && key.dir === "left") return <ChevronLeft className="size-4" />;
  if (key.kind === "move" && key.dir === "right") return <ChevronRight className="size-4" />;
  if (key.kind === "backspace") return <Delete className="size-4" />;
  if (key.kind === "complete") return "abc";
  if (key.kind === "cmd") return key.label;
  return key.label;
}

function ariaFor(key: KeySpec) {
  if (key.kind === "text") return `Insert ${key.label}`;
  if (key.kind === "cmd") return key.cmd === "tab" ? "Indent" : key.cmd;
  if (key.kind === "move") return `Cursor ${key.dir}`;
  if (key.kind === "complete") return "Suggestions";
  return "Backspace";
}
