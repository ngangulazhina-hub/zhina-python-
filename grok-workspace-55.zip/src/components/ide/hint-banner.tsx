import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useIdeStore } from "@/lib/ide/store";

export function HintBanner() {
  const dismissed = useIdeStore((s) => s.hintDismissed);
  const dismiss = useIdeStore((s) => s.dismissHint);
  if (dismissed) return null;
  return (
    <div className="flex items-start gap-2 border-b border-border bg-elevated px-3 py-2 text-sm text-fg">
      <p className="min-w-0 flex-1 leading-relaxed">
        Tap Run to execute. The key bar above the keyboard inserts brackets and quotes.
        Recent files sit under the title. Vol pad moves the cursor.
      </p>
      <Button type="button" variant="ghost" size="icon" className="size-9 shrink-0" aria-label="Dismiss" onClick={dismiss}>
        <X className="size-4" />
      </Button>
    </div>
  );
}
