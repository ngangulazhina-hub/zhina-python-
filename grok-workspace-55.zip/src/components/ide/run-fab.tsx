import { Play, Square } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useIdeStore } from "@/lib/ide/store";
import { cn } from "@/lib/utils";

export function RunFab({ keyboardInset = 0 }: { keyboardInset?: number }) {
  const status = useIdeStore((s) => s.status);
  const running = status === "running";
  const loading = status === "loading";

  return (
    <Button
      type="button"
      size="fab"
      className={cn(
        "fixed z-40",
        running ? "bg-danger text-fg" : "bg-accent text-accent-fg",
        loading && !running ? "opacity-80" : "",
      )}
      style={{
        right: "max(1rem, env(safe-area-inset-right))",
        bottom: `calc(${keyboardInset}px + 3.25rem + ${keyboardInset > 0 ? "0px" : "env(safe-area-inset-bottom)"} + 0.75rem)`,
      }}
      aria-label={running ? "Stop" : loading ? "Loading Python — tap to queue a run" : "Run"}
      onClick={() => {
        window.dispatchEvent(new CustomEvent(running ? "zhina-stop" : "zhina-run"));
      }}
    >
      {running ? (
        <Square className="size-5 fill-current" />
      ) : (
        <Play className="size-6 fill-current" style={{ marginLeft: 2 }} />
      )}
    </Button>
  );
}
