import { useRef } from "react";
import { ChevronDown, ChevronLeft, ChevronRight, ChevronUp } from "lucide-react";
import type { EditorView } from "@codemirror/view";
import { moveCursor, type CursorDir } from "@/lib/editor/volume-cursor";
import { useIdeStore } from "@/lib/ide/store";

export function VolumeRocker({ viewRef }: { viewRef: React.MutableRefObject<EditorView | null> }) {
  const enabled = useIdeStore((s) => s.settings.volumeCursor);
  const timer = useRef<number | null>(null);

  if (!enabled) return null;

  const hold = (dir: CursorDir) => {
    const step = () => {
      if (viewRef.current) moveCursor(viewRef.current, dir);
    };
    step();
    const id = window.setTimeout(() => {
      timer.current = window.setInterval(step, 70);
    }, 380);
    const stop = () => {
      window.clearTimeout(id);
      if (timer.current) window.clearInterval(timer.current);
      timer.current = null;
      window.removeEventListener("pointerup", stop);
      window.removeEventListener("pointercancel", stop);
    };
    window.addEventListener("pointerup", stop);
    window.addEventListener("pointercancel", stop);
  };

  return (
    <div className="pointer-events-auto absolute top-[28%] right-1 z-30 flex flex-col items-center gap-2">
      <div className="flex w-11 flex-col overflow-hidden rounded-xl bg-elevated shadow-[var(--shadow-border),var(--shadow-lift)]">
        <p className="bg-surface py-1 text-center text-[9px] font-medium tracking-widest text-muted uppercase">
          Vol
        </p>
        <button
          type="button"
          className="flex h-12 items-center justify-center text-fg active:bg-surface"
          aria-label="Volume up — move cursor up"
          onPointerDown={(e) => {
            e.preventDefault();
            e.stopPropagation();
            hold("up");
          }}
        >
          <ChevronUp className="size-5" />
        </button>
        <div className="h-px bg-border" />
        <button
          type="button"
          className="flex h-12 items-center justify-center text-fg active:bg-surface"
          aria-label="Volume down — move cursor down"
          onPointerDown={(e) => {
            e.preventDefault();
            e.stopPropagation();
            hold("down");
          }}
        >
          <ChevronDown className="size-5" />
        </button>
      </div>
      <div className="flex overflow-hidden rounded-xl bg-elevated shadow-[var(--shadow-border)]">
        <button
          type="button"
          className="flex size-11 items-center justify-center text-fg active:bg-surface"
          aria-label="Move cursor left"
          onPointerDown={(e) => {
            e.preventDefault();
            hold("left");
          }}
        >
          <ChevronLeft className="size-4" />
        </button>
        <div className="w-px bg-border" />
        <button
          type="button"
          className="flex size-11 items-center justify-center text-fg active:bg-surface"
          aria-label="Move cursor right"
          onPointerDown={(e) => {
            e.preventDefault();
            hold("right");
          }}
        >
          <ChevronRight className="size-4" />
        </button>
      </div>
    </div>
  );
}
