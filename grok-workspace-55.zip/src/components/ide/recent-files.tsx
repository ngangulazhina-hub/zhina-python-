import { useState } from "react";
import { Plus, X } from "lucide-react";
import { useIdeStore, type IdeFile } from "@/lib/ide/store";
import { cn } from "@/lib/utils";

export function RecentFiles() {
  const files = useIdeStore((s) => s.files);
  const activeFileId = useIdeStore((s) => s.activeFileId);
  const openFile = useIdeStore((s) => s.openFile);
  const closeFile = useIdeStore((s) => s.closeFile);
  const newFile = useIdeStore((s) => s.newFile);
  const renameFile = useIdeStore((s) => s.renameFile);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState("");

  const startRename = (file: IdeFile) => {
    setEditingId(file.id);
    setDraft(file.name.replace(/\.py$/i, ""));
  };

  const commitRename = () => {
    if (editingId && draft.trim()) renameFile(editingId, draft.trim());
    setEditingId(null);
  };

  return (
    <div className="flex h-11 shrink-0 items-center gap-1 border-b border-border bg-surface px-1.5">
      <p className="hidden shrink-0 px-1.5 text-[10px] font-medium tracking-wide text-muted uppercase sm:block">
        Recent
      </p>
      <div className="flex min-w-0 flex-1 items-center gap-1 overflow-x-auto py-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {files.map((file) => {
          const active = file.id === activeFileId;
          return (
            <div
              key={file.id}
              className={cn(
                "flex h-8 max-w-[11rem] shrink-0 items-center rounded-lg pl-2.5",
                active ? "bg-accent text-accent-fg" : "bg-elevated text-fg",
              )}
            >
              {editingId === file.id ? (
                <input
                  value={draft}
                  autoFocus
                  aria-label="Rename file"
                  className="h-7 w-24 bg-transparent text-xs outline-none"
                  onChange={(e) => setDraft(e.target.value)}
                  onBlur={commitRename}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") commitRename();
                    if (e.key === "Escape") setEditingId(null);
                  }}
                />
              ) : (
                <button
                  type="button"
                  className="min-w-0 truncate font-mono text-xs"
                  title={file.name}
                  onClick={() => (active ? startRename(file) : openFile(file.id))}
                >
                  {file.name}
                </button>
              )}
              <button
                type="button"
                className={cn(
                  "flex size-8 shrink-0 items-center justify-center rounded-md",
                  active ? "text-accent-fg/80" : "text-muted",
                )}
                aria-label={`Close ${file.name}`}
                onClick={(e) => {
                  e.stopPropagation();
                  closeFile(file.id);
                }}
              >
                <X className="size-3.5" />
              </button>
            </div>
          );
        })}
      </div>
      <button
        type="button"
        className="flex size-9 shrink-0 items-center justify-center rounded-lg text-fg hover:bg-elevated"
        aria-label="New file"
        onClick={() => newFile()}
      >
        <Plus className="size-4" />
      </button>
    </div>
  );
}
