import { i as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { C as ArrowLeft, S as Book, _ as CircleAlert, a as Terminal, b as ChevronLeft, c as Redo2, d as Menu, f as FolderOpen, g as Copy, h as Delete, i as Trash2, l as Plus, m as Download, n as Undo2, o as Square, p as ExternalLink, s as Settings, t as X, u as Play, v as ChevronUp, x as ChevronDown, y as ChevronRight } from "../_libs/lucide-react.mjs";
import { i as useIdeStore, n as FONT_FAMILIES, r as THEME_PRESETS, t as EXAMPLES } from "./store-Dayi5z8g.mjs";
import { n as require_react_dom } from "../_libs/@radix-ui/react-primitive+[...].mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { $ as layer, C as indentUnit, G as dropCursor, H as ViewPlugin, O as tags, Q as keymap, T as syntaxHighlighting, V as RectangleMarker, W as drawSelection, X as highlightActiveLineGutter, Y as highlightActiveLine, a as completionKeymap, c as startCompletion, et as lineNumbers, ft as Compartment, h as foldGutter, l as HighlightStyle, mt as EditorState, n as closeBrackets, ot as tooltips, p as bracketMatching, r as closeBracketsKeymap, s as snippetCompletion, t as autocompletion, x as indentOnInput, z as EditorView } from "../_libs/@codemirror/autocomplete+[...].mjs";
import { a as indentMore, c as undo, i as indentLess, n as history, o as indentWithTab, r as historyKeymap, s as redo, t as defaultKeymap } from "../_libs/codemirror__commands.mjs";
import { n as parser, t as python } from "../_libs/@codemirror/lang-python+[...].mjs";
import { n as searchKeymap, t as highlightSelectionMatches } from "../_libs/codemirror__search.mjs";
import { n as linter, t as lintGutter } from "../_libs/codemirror__lint.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/radix-ui__react-switch.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BQgTfPMh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom());
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[opacity,transform,background-color,color] duration-150 ease-out active:not-disabled:scale-[0.96] disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:opacity-90",
			secondary: "bg-elevated text-fg shadow-[var(--shadow-border)] hover:bg-surface",
			ghost: "text-fg hover:bg-elevated",
			outline: "text-fg shadow-[var(--shadow-border)] hover:bg-elevated",
			danger: "bg-danger text-fg hover:opacity-90"
		},
		size: {
			default: "h-11 rounded-[10px] px-4 text-sm",
			sm: "h-9 rounded-lg px-3 text-sm",
			lg: "h-12 rounded-xl px-5 text-base",
			icon: "size-11 rounded-[10px]",
			fab: "size-14 rounded-full shadow-[var(--shadow-lift)]"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
	ref,
	className: cn(buttonVariants({
		variant,
		size
	}), className),
	...props
}));
Button.displayName = "Button";
function IdeHeader() {
	const setScreen = useIdeStore((s) => s.setScreen);
	const upsertNamedFile = useIdeStore((s) => s.upsertNamedFile);
	const layout = useIdeStore((s) => s.terminalLayout);
	const screen = useIdeStore((s) => s.screen);
	const [menu, setMenu] = (0, import_react.useState)(false);
	const [examples, setExamples] = (0, import_react.useState)(false);
	const openFile = () => {
		const input = document.createElement("input");
		input.type = "file";
		input.accept = ".py,text/x-python,text/plain";
		input.onchange = () => {
			const file = input.files?.[0];
			if (!file) return;
			file.text().then((text) => upsertNamedFile(file.name || "upload.py", text));
		};
		input.click();
	};
	const saveFile = () => {
		const state = useIdeStore.getState();
		const current = state.files.find((f) => f.id === state.activeFileId);
		const blob = new Blob([state.code], { type: "text/x-python" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = current?.name || "main.py";
		a.click();
		URL.revokeObjectURL(url);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "relative z-50 flex h-12 shrink-0 items-center gap-1 border-b border-border bg-bg px-2 pt-[env(safe-area-inset-top)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 items-center gap-2 pl-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm font-medium tracking-tight",
						children: "Zhina"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-[11px] text-muted",
						children: "Python"
					})]
				})]
			}),
			layout === "screen" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mr-1 flex rounded-lg bg-elevated p-0.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `h-8 rounded-md px-3 text-xs ${screen === "editor" ? "bg-surface text-fg" : "text-muted"}`,
					onClick: () => setScreen("editor"),
					children: "Code"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `h-8 rounded-md px-3 text-xs ${screen === "terminal" ? "bg-surface text-fg" : "text-muted"}`,
					onClick: () => setScreen("terminal"),
					children: "Output"
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "ghost",
				size: "sm",
				className: "hidden h-10 px-2 sm:inline-flex",
				onClick: () => setExamples(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Book, { className: "size-4" }), "Examples"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "ghost",
				size: "icon",
				className: "size-11 sm:hidden",
				"aria-label": "Examples",
				onClick: () => setExamples(true),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Book, { className: "size-5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "ghost",
				size: "icon",
				className: "size-11",
				"aria-label": "Menu",
				onClick: () => setMenu(true),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "ghost",
				size: "icon",
				className: "size-11",
				"aria-label": "Settings",
				onClick: () => setScreen("settings"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-5" })
			}),
			examples ? (0, import_react_dom.createPortal)(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				title: "Examples",
				onClose: () => setExamples(false),
				children: EXAMPLES.map((ex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "flex min-h-12 w-full items-center rounded-xl px-4 text-left text-sm hover:bg-elevated",
					onClick: () => {
						upsertNamedFile(`${ex.id}.py`, ex.code);
						setExamples(false);
						setScreen("editor");
					},
					children: ex.title
				}, ex.id))
			}), document.body) : null,
			menu ? (0, import_react_dom.createPortal)(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
				title: "Menu",
				onClose: () => setMenu(false),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }),
						label: "New file",
						onClick: () => {
							useIdeStore.getState().newFile();
							setMenu(false);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOpen, { className: "size-4" }),
						label: "Open .py file",
						onClick: () => {
							openFile();
							setMenu(false);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }),
						label: "Download .py",
						onClick: () => {
							saveFile();
							setMenu(false);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Book, { className: "size-4" }),
						label: "Libraries",
						onClick: () => {
							setScreen("libraries");
							setMenu(false);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Terminal, { className: "size-4" }),
						label: layout === "below" ? "Terminal on its own screen" : "Terminal under editor",
						onClick: () => {
							useIdeStore.getState().setTerminalLayout(layout === "below" ? "screen" : "below");
							setMenu(false);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-4" }),
						label: "Settings",
						onClick: () => {
							setScreen("settings");
							setMenu(false);
						}
					})
				]
			}), document.body) : null
		]
	});
}
function Item({ icon, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: "flex min-h-12 w-full items-center gap-3 rounded-xl px-4 text-left text-sm hover:bg-elevated",
		onClick,
		children: [icon, label]
	});
}
function Sheet({ title, onClose, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-[80] flex items-end justify-center sm:items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "absolute inset-0 bg-bg/70",
			"aria-label": "Close",
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mb-0 w-full max-w-md rounded-t-3xl bg-surface p-3 pb-[max(1rem,env(safe-area-inset-bottom))] shadow-[var(--shadow-lift)] sm:mb-8 sm:rounded-3xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between px-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-medium",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					size: "icon",
					className: "size-10",
					"aria-label": "Close",
					onClick: onClose,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "max-h-[70dvh] overflow-auto",
				children
			})]
		})]
	});
}
function Logo() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: "28",
		height: "28",
		viewBox: "0 0 28 28",
		"aria-hidden": true,
		className: "shrink-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			width: "28",
			height: "28",
			rx: "7",
			fill: "currentColor",
			className: "text-accent"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M8 8h12l-8 6 8 6H8",
			fill: "none",
			stroke: "currentColor",
			className: "text-accent-fg",
			strokeWidth: "2.1",
			strokeLinejoin: "round"
		})]
	});
}
var KEYWORDS = [
	"False",
	"None",
	"True",
	"and",
	"as",
	"assert",
	"async",
	"await",
	"break",
	"continue",
	"del",
	"elif",
	"else",
	"except",
	"finally",
	"from",
	"global",
	"import",
	"in",
	"is",
	"lambda",
	"nonlocal",
	"not",
	"or",
	"pass",
	"raise",
	"return",
	"yield"
].map((label) => ({
	label,
	type: "keyword",
	boost: 20
}));
var BUILTINS = [
	"abs",
	"all",
	"any",
	"ascii",
	"bin",
	"bool",
	"bytearray",
	"bytes",
	"callable",
	"chr",
	"classmethod",
	"compile",
	"complex",
	"dict",
	"dir",
	"divmod",
	"enumerate",
	"eval",
	"exec",
	"filter",
	"float",
	"format",
	"frozenset",
	"getattr",
	"globals",
	"hasattr",
	"hash",
	"help",
	"hex",
	"id",
	"input",
	"int",
	"isinstance",
	"issubclass",
	"iter",
	"len",
	"list",
	"locals",
	"map",
	"max",
	"min",
	"next",
	"object",
	"oct",
	"open",
	"ord",
	"pow",
	"print",
	"property",
	"range",
	"repr",
	"reversed",
	"round",
	"set",
	"setattr",
	"slice",
	"sorted",
	"staticmethod",
	"str",
	"sum",
	"super",
	"tuple",
	"type",
	"vars",
	"zip"
].map((label) => ({
	label,
	type: "function",
	boost: label === "print" || label === "len" || label === "range" || label === "input" ? 50 : 10
}));
var MODULES = [
	"math",
	"random",
	"statistics",
	"datetime",
	"time",
	"json",
	"re",
	"os",
	"sys",
	"pathlib",
	"collections",
	"itertools",
	"functools",
	"typing",
	"dataclasses",
	"csv",
	"io",
	"base64",
	"hashlib",
	"decimal",
	"fractions",
	"pprint",
	"unittest",
	"traceback",
	"ast",
	"numpy",
	"pandas",
	"matplotlib",
	"matplotlib.pyplot",
	"scipy",
	"sklearn",
	"PIL",
	"sympy",
	"networkx"
].map((label) => ({
	label,
	type: "namespace",
	boost: 15
}));
var SNIPPETS = [
	snippetCompletion("def ${name}(${args}):\n    ${pass}", {
		label: "def",
		type: "keyword",
		detail: "function",
		boost: 80
	}),
	snippetCompletion("class ${Name}:\n    def __init__(self):\n        ${pass}", {
		label: "class",
		type: "keyword",
		detail: "class",
		boost: 70
	}),
	snippetCompletion("if ${condition}:\n    ${pass}", {
		label: "if",
		type: "keyword",
		boost: 70
	}),
	snippetCompletion("elif ${condition}:\n    ${pass}", {
		label: "elif",
		type: "keyword",
		boost: 40
	}),
	snippetCompletion("for ${item} in ${iterable}:\n    ${pass}", {
		label: "for",
		type: "keyword",
		boost: 70
	}),
	snippetCompletion("while ${condition}:\n    ${pass}", {
		label: "while",
		type: "keyword",
		boost: 70
	}),
	snippetCompletion("try:\n    ${pass}\nexcept ${Exception} as ${exc}:\n    ${raise}", {
		label: "try",
		type: "keyword",
		boost: 60
	}),
	snippetCompletion("with ${expr} as ${name}:\n    ${pass}", {
		label: "with",
		type: "keyword",
		boost: 50
	}),
	snippetCompletion("if __name__ == \"__main__\":\n    ${main()}", {
		label: "main",
		type: "snippet",
		detail: "entrypoint",
		boost: 40
	}),
	snippetCompletion("print(${value})", {
		label: "print()",
		type: "function",
		boost: 90
	}),
	snippetCompletion("input(${prompt})", {
		label: "input()",
		type: "function",
		boost: 60
	})
];
var MEMBERS = {
	math: [
		"sqrt",
		"sin",
		"cos",
		"tan",
		"pi",
		"e",
		"floor",
		"ceil",
		"log",
		"log10",
		"exp",
		"pow",
		"radians",
		"degrees",
		"fabs"
	],
	random: [
		"random",
		"randint",
		"choice",
		"shuffle",
		"sample",
		"seed",
		"uniform",
		"gauss",
		"randrange"
	],
	json: [
		"loads",
		"dumps",
		"load",
		"dump"
	],
	re: [
		"compile",
		"search",
		"match",
		"findall",
		"sub",
		"split",
		"fullmatch"
	],
	os: [
		"path",
		"getcwd",
		"listdir",
		"environ",
		"name"
	],
	sys: [
		"version",
		"argv",
		"path",
		"platform",
		"exit",
		"stdin",
		"stdout",
		"stderr"
	],
	time: [
		"sleep",
		"time",
		"strftime",
		"localtime"
	],
	datetime: [
		"datetime",
		"date",
		"time",
		"timedelta"
	],
	np: [
		"array",
		"arange",
		"linspace",
		"zeros",
		"ones",
		"dot",
		"mean",
		"sum",
		"shape",
		"reshape",
		"concatenate"
	],
	numpy: [
		"array",
		"arange",
		"linspace",
		"zeros",
		"ones",
		"dot",
		"mean"
	],
	pd: [
		"DataFrame",
		"Series",
		"read_csv",
		"concat",
		"to_csv"
	],
	pandas: [
		"DataFrame",
		"Series",
		"read_csv",
		"concat"
	],
	plt: [
		"plot",
		"scatter",
		"bar",
		"hist",
		"show",
		"title",
		"xlabel",
		"ylabel",
		"legend",
		"subplots",
		"tight_layout",
		"savefig"
	],
	str: [
		"split",
		"join",
		"strip",
		"replace",
		"format",
		"lower",
		"upper",
		"startswith",
		"endswith",
		"find"
	],
	list: [
		"append",
		"extend",
		"pop",
		"sort",
		"reverse",
		"index",
		"count",
		"insert",
		"remove"
	],
	dict: [
		"get",
		"keys",
		"values",
		"items",
		"update",
		"pop",
		"setdefault"
	]
};
function identifiersIn(doc) {
	const found = /* @__PURE__ */ new Set();
	for (const m of doc.matchAll(/^\s*(?:async\s+)?def\s+([A-Za-z_]\w*)/gm)) if (m[1]) found.add(m[1]);
	for (const m of doc.matchAll(/^\s*class\s+([A-Za-z_]\w*)/gm)) if (m[1]) found.add(m[1]);
	for (const m of doc.matchAll(/^\s*([A-Za-z_]\w*)\s*=/gm)) if (m[1]) found.add(m[1]);
	return [...found].map((label) => ({
		label,
		type: "variable",
		boost: 30
	}));
}
function matches(label, query) {
	if (!query) return true;
	const l = label.toLowerCase();
	const q = query.toLowerCase();
	return l.startsWith(q) || l.includes(q);
}
function pythonCompletions(context) {
	const importBefore = context.matchBefore(/(?:from|import)\s+[\w.]*$/);
	if (importBefore) {
		const start = importBefore.from + importBefore.text.search(/[\w.]+$/);
		const typed = importBefore.text.match(/[\w.]+$/)?.[0] ?? "";
		return {
			from: start < 0 ? importBefore.to : start,
			options: MODULES.filter((m) => matches(m.label, typed)),
			validFor: /^[\w.]*$/,
			filter: false
		};
	}
	const dotted = context.matchBefore(/[A-Za-z_][\w]*\.\w*$/);
	if (dotted) {
		const parts = dotted.text.split(".");
		const obj = parts[0] ?? "";
		const partial = parts.slice(1).join(".");
		const members = MEMBERS[obj] ?? [];
		return {
			from: dotted.from + obj.length + 1,
			options: members.filter((m) => matches(m, partial)).map((label) => ({
				label,
				type: "property",
				boost: 40
			})),
			validFor: /^\w*$/,
			filter: false
		};
	}
	const word = context.matchBefore(/[A-Za-z_]\w*/);
	if (!word) {
		if (context.explicit) return {
			from: context.pos,
			options: [
				...SNIPPETS,
				...KEYWORDS,
				...BUILTINS
			],
			filter: false
		};
		return null;
	}
	if (word.from === word.to && !context.explicit) return null;
	const q = word.text;
	const local = identifiersIn(context.state.doc.toString());
	const options = [
		...SNIPPETS,
		...KEYWORDS,
		...BUILTINS,
		...MODULES,
		...local
	].filter((o) => matches(o.label, q));
	if (!options.length && !context.explicit) return null;
	return {
		from: word.from,
		options,
		validFor: /^\w*$/,
		filter: false
	};
}
function pythonAutocomplete() {
	return autocompletion({
		override: [pythonCompletions],
		defaultKeymap: true,
		activateOnTyping: true,
		activateOnTypingDelay: 40,
		closeOnBlur: false,
		icons: true,
		tooltipClass: () => "zhina-complete",
		optionClass: () => "zhina-complete-item",
		maxRenderedOptions: 12
	});
}
function indentOf(text, tabSize) {
	let n = 0;
	for (const ch of text) if (ch === " ") n += 1;
	else if (ch === "	") n += tabSize;
	else break;
	return n;
}
function isBlank(text) {
	return !text.trim();
}
function currentBlock(doc, lineNumber, tabSize) {
	const line = doc.line(lineNumber);
	let indent = indentOf(line.text, tabSize);
	if (isBlank(line.text)) {
		let up = lineNumber;
		while (up > 1 && isBlank(doc.line(up).text)) up -= 1;
		indent = indentOf(doc.line(up).text, tabSize);
	}
	let start = lineNumber;
	while (start > 1) {
		const prev = doc.line(start - 1);
		if (isBlank(prev.text)) {
			start -= 1;
			continue;
		}
		if (indentOf(prev.text, tabSize) < indent) break;
		start -= 1;
	}
	let end = lineNumber;
	while (end < doc.lines) {
		const next = doc.line(end + 1);
		if (isBlank(next.text)) {
			end += 1;
			continue;
		}
		if (indentOf(next.text, tabSize) < indent) break;
		end += 1;
	}
	while (end > start && isBlank(doc.line(end).text)) end -= 1;
	return {
		start,
		end,
		indent
	};
}
var BlockGuides = class {
	view;
	constructor(view) {
		this.view = view;
	}
	update(_u) {}
};
function blockLines(enabled, tabSize) {
	if (!enabled) return [];
	const blockLayer = layer({
		above: false,
		class: "cm-zhina-blocks",
		update(update) {
			return update.docChanged || update.viewportChanged || update.selectionSet || update.geometryChanged;
		},
		markers(view) {
			const markers = [];
			const tab = tabSize || 4;
			const charW = view.defaultCharacterWidth;
			const contentLeft = view.contentDOM.getBoundingClientRect().left - view.scrollDOM.getBoundingClientRect().left + view.scrollDOM.scrollLeft;
			const sel = view.state.selection.main;
			const currentLine = view.state.doc.lineAt(sel.head);
			const block = currentBlock(view.state.doc, currentLine.number, tab);
			const startBlock = view.lineBlockAt(view.state.doc.line(block.start).from);
			const endBlock = view.lineBlockAt(view.state.doc.line(block.end).from);
			const top = startBlock.top;
			const height = endBlock.bottom - startBlock.top;
			const bandLeft = contentLeft + block.indent * charW;
			if (height > 0) {
				markers.push(new RectangleMarker("zhina-block-band", 0, top, view.scrollDOM.scrollWidth, height));
				markers.push(new RectangleMarker("zhina-block-bar", bandLeft, top, 2, height));
			}
			const { from, to } = view.viewport;
			let lineNo = view.state.doc.lineAt(from).number;
			const last = view.state.doc.lineAt(to).number;
			const seen = /* @__PURE__ */ new Set();
			for (; lineNo <= last; lineNo++) {
				const line = view.state.doc.line(lineNo);
				if (isBlank(line.text)) continue;
				const indent = indentOf(line.text, tab);
				const levels = Math.floor(indent / tab);
				const lb = view.lineBlockAt(line.from);
				for (let i = 1; i <= levels; i++) {
					const key = `${lb.top}:${i}`;
					if (seen.has(key)) continue;
					seen.add(key);
					const x = contentLeft + i * tab * charW;
					markers.push(new RectangleMarker("zhina-guide", x, lb.top, 1, lb.height));
				}
			}
			return markers;
		}
	});
	return [
		ViewPlugin.fromClass(BlockGuides),
		blockLayer,
		EditorView.theme({ ".cm-zhina-blocks": { pointerEvents: "none" } })
	];
}
function editorTheme(settings) {
	const highlight = HighlightStyle.define([
		{
			tag: tags.comment,
			color: settings.editorComment,
			fontStyle: "italic"
		},
		{
			tag: tags.lineComment,
			color: settings.editorComment,
			fontStyle: "italic"
		},
		{
			tag: tags.keyword,
			color: settings.editorKeyword
		},
		{
			tag: tags.controlKeyword,
			color: settings.editorKeyword
		},
		{
			tag: tags.definitionKeyword,
			color: settings.editorKeyword
		},
		{
			tag: tags.operatorKeyword,
			color: settings.editorKeyword
		},
		{
			tag: tags.string,
			color: settings.editorString
		},
		{
			tag: tags.number,
			color: settings.editorNumber
		},
		{
			tag: tags.bool,
			color: settings.editorKeyword
		},
		{
			tag: tags.null,
			color: settings.editorKeyword
		},
		{
			tag: tags.function(tags.definition(tags.variableName)),
			color: settings.editorFunction
		},
		{
			tag: tags.function(tags.variableName),
			color: settings.editorFunction
		},
		{
			tag: tags.className,
			color: settings.editorFunction
		},
		{
			tag: tags.definition(tags.variableName),
			color: settings.editorFg
		},
		{
			tag: tags.self,
			color: settings.editorKeyword
		},
		{
			tag: tags.propertyName,
			color: settings.editorFg
		},
		{
			tag: tags.operator,
			color: settings.editorFg
		},
		{
			tag: tags.punctuation,
			color: settings.editorFg
		},
		{
			tag: tags.meta,
			color: settings.editorComment
		},
		{
			tag: tags.invalid,
			color: "#d4726a"
		}
	]);
	return [EditorView.theme({
		"&": {
			backgroundColor: settings.editorBg,
			color: settings.editorFg
		},
		".cm-content": {
			caretColor: settings.editorCursor,
			fontFamily: settings.fontFamily,
			fontSize: `${settings.fontSize}px`,
			fontWeight: settings.fontWeight,
			fontStyle: settings.fontStyle
		},
		".cm-gutters": {
			backgroundColor: settings.editorBg,
			color: settings.editorGutter,
			border: "none"
		},
		".cm-activeLine": { backgroundColor: settings.editorLine },
		".cm-activeLineGutter": {
			backgroundColor: settings.editorLine,
			color: settings.editorFg
		},
		"&.cm-focused .cm-selectionBackground, .cm-selectionBackground, .cm-content ::selection": { backgroundColor: settings.editorSelection },
		".cm-cursor, .cm-dropCursor": { borderLeftColor: settings.editorCursor },
		".cm-matchingBracket": {
			outline: `1px solid ${settings.editorKeyword}`,
			backgroundColor: "transparent"
		}
	}, { dark: luminance(settings.editorBg) < .45 }), syntaxHighlighting(highlight)];
}
function luminance(hex) {
	const c = hex.replace("#", "");
	if (c.length < 6) return 0;
	const r = parseInt(c.slice(0, 2), 16) / 255;
	const g = parseInt(c.slice(2, 4), 16) / 255;
	const b = parseInt(c.slice(4, 6), 16) / 255;
	return .2126 * r + .7152 * g + .0722 * b;
}
function editorCssVars(settings) {
	return {
		"--ed-bg": settings.editorBg,
		"--ed-fg": settings.editorFg,
		"--ed-gutter": settings.editorGutter,
		"--ed-selection": settings.editorSelection,
		"--ed-line": settings.editorLine,
		"--ed-block": settings.editorBlock,
		"--ed-guide": settings.editorGuide,
		"--ed-cursor": settings.editorCursor,
		"--ed-comment": settings.editorComment,
		"--ed-keyword": settings.editorKeyword,
		"--ed-string": settings.editorString,
		"--ed-font": settings.fontFamily,
		"--ed-size": `${settings.fontSize}px`,
		"--ed-weight": settings.fontWeight,
		"--ed-style": settings.fontStyle
	};
}
var VOLUME_UP = /* @__PURE__ */ new Set([
	"AudioVolumeUp",
	"VolumeUp",
	"MediaVolumeUp",
	"XF86AudioRaiseVolume",
	"AudioRaiseVolume"
]);
var VOLUME_DOWN = /* @__PURE__ */ new Set([
	"AudioVolumeDown",
	"VolumeDown",
	"MediaVolumeDown",
	"XF86AudioLowerVolume",
	"AudioLowerVolume"
]);
function isVolumeKey(e) {
	const key = e.key || "";
	const code = e.code || "";
	if (VOLUME_UP.has(key) || VOLUME_UP.has(code)) return 1;
	if (VOLUME_DOWN.has(key) || VOLUME_DOWN.has(code)) return -1;
	const kc = e.keyCode || e.which;
	if (kc === 24 || kc === 175 || kc === 183 || kc === 38 && e.altKey) return 1;
	if (kc === 25 || kc === 174 || kc === 182 || kc === 40 && e.altKey) return -1;
	if (key === "Unidentified") {
		if (kc === 24) return 1;
		if (kc === 25) return -1;
	}
	return 0;
}
function moveCursor(view, dir) {
	const head = view.state.selection.main.head;
	if (dir === "left" || dir === "right") {
		const next = dir === "left" ? Math.max(0, head - 1) : Math.min(view.state.doc.length, head + 1);
		view.dispatch({
			selection: { anchor: next },
			scrollIntoView: true
		});
		view.focus();
		return;
	}
	moveCursorLine(view, dir === "up" ? -1 : 1);
}
function moveCursorLine(view, direction) {
	const head = view.state.selection.main.head;
	const line = view.state.doc.lineAt(head);
	const col = head - line.from;
	const nextNo = line.number + direction;
	if (nextNo < 1 || nextNo > view.state.doc.lines) return;
	const next = view.state.doc.line(nextNo);
	const pos = next.from + Math.min(col, next.length);
	view.dispatch({
		selection: { anchor: pos },
		scrollIntoView: true
	});
	view.focus();
}
function attachVolumeKeys(getView, enabled) {
	const onKey = (e) => {
		if (!enabled()) return;
		if (!(e instanceof KeyboardEvent)) return;
		if (e.type !== "keydown") return;
		const dir = isVolumeKey(e);
		if (!dir) return;
		const view = getView();
		if (!view) return;
		e.preventDefault();
		e.stopPropagation();
		moveCursorLine(view, dir === 1 ? -1 : 1);
	};
	window.addEventListener("keydown", onKey, { capture: true });
	return () => {
		window.removeEventListener("keydown", onKey, { capture: true });
	};
}
var themeComp = new Compartment();
var wrapComp = new Compartment();
var tabComp = new Compartment();
var blockComp = new Compartment();
var lintComp = new Compartment();
function toCmDiagnostics() {
	const diags = useIdeStore.getState().diagnostics;
	const doc = useIdeStore.getState().code;
	return diags.map((d) => {
		const from = d.from || offsetFromLine(doc, d.line, d.column);
		return {
			from,
			to: d.to && d.to > from ? d.to : Math.min(doc.length, from + 1),
			severity: d.severity === "warning" ? "warning" : "error",
			message: `${d.type}: ${d.message}`
		};
	});
}
function offsetFromLine(code, line, column) {
	const lines = code.split("\n");
	let off = 0;
	for (let i = 0; i < Math.max(0, line - 1); i++) off += (lines[i]?.length ?? 0) + 1;
	return Math.min(code.length, off + Math.max(0, column - 1));
}
function PythonEditor({ viewRef, className }) {
	const hostRef = (0, import_react.useRef)(null);
	const settings = useIdeStore((s) => s.settings);
	const setCode = useIdeStore((s) => s.setCode);
	const setCursor = useIdeStore((s) => s.setCursor);
	(0, import_react.useEffect)(() => {
		if (!hostRef.current || viewRef.current) return;
		const start = useIdeStore.getState().code;
		const s = useIdeStore.getState().settings;
		const updateListener = EditorView.updateListener.of((update) => {
			if (update.docChanged) setCode(update.state.doc.toString());
			const head = update.state.selection.main.head;
			const line = update.state.doc.lineAt(head);
			setCursor(line.number, head - line.from + 1);
		});
		const runKey = keymap.of([
			{
				key: "Mod-Enter",
				run: () => {
					window.dispatchEvent(new CustomEvent("zhina-run"));
					return true;
				}
			},
			{
				key: "Ctrl-Space",
				mac: "Cmd-Space",
				run: startCompletion
			},
			{
				key: "Mod-.",
				run: () => {
					useIdeStore.getState().setScreen("settings");
					return true;
				}
			}
		]);
		const state = EditorState.create({
			doc: start,
			extensions: [
				lineNumbers(),
				highlightActiveLine(),
				highlightActiveLineGutter(),
				foldGutter(),
				drawSelection(),
				dropCursor(),
				history(),
				indentOnInput(),
				bracketMatching(),
				closeBrackets(),
				python(),
				pythonAutocomplete(),
				tooltips({ parent: document.body }),
				highlightSelectionMatches(),
				lintGutter(),
				lintComp.of(linter(() => toCmDiagnostics(), { delay: 400 })),
				keymap.of([
					...completionKeymap,
					...closeBracketsKeymap,
					...defaultKeymap,
					...historyKeymap,
					...searchKeymap,
					indentWithTab
				]),
				runKey,
				themeComp.of(editorTheme(s)),
				wrapComp.of(s.wordWrap ? EditorView.lineWrapping : []),
				tabComp.of([EditorState.tabSize.of(s.tabSize), indentUnit.of(" ".repeat(s.tabSize))]),
				blockComp.of(blockLines(s.showBlockLines, s.tabSize)),
				updateListener,
				EditorView.theme({
					"&": { height: "100%" },
					".cm-scroller": { overflow: "auto" }
				})
			]
		});
		const view = new EditorView({
			state,
			parent: hostRef.current
		});
		viewRef.current = view;
		return () => {
			view.destroy();
			viewRef.current = null;
		};
	}, [
		setCode,
		setCursor,
		viewRef
	]);
	(0, import_react.useEffect)(() => {
		const view = viewRef.current;
		if (!view) return;
		view.dispatch({ effects: [
			themeComp.reconfigure(editorTheme(settings)),
			wrapComp.reconfigure(settings.wordWrap ? EditorView.lineWrapping : []),
			tabComp.reconfigure([EditorState.tabSize.of(settings.tabSize), indentUnit.of(" ".repeat(settings.tabSize))]),
			blockComp.reconfigure(blockLines(settings.showBlockLines, settings.tabSize))
		] });
	}, [settings, viewRef]);
	(0, import_react.useEffect)(() => {
		return useIdeStore.subscribe((state, prev) => {
			if (state.code === prev.code) return;
			const view = viewRef.current;
			if (!view) return;
			if (view.state.doc.toString() === state.code) return;
			view.dispatch({ changes: {
				from: 0,
				to: view.state.doc.length,
				insert: state.code
			} });
		});
	}, [viewRef]);
	(0, import_react.useEffect)(() => {
		return attachVolumeKeys(() => viewRef.current, () => useIdeStore.getState().settings.volumeCursor);
	}, [viewRef]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("zhina-cm min-h-0 flex-1 overflow-hidden", className),
		style: editorCssVars(settings),
		ref: hostRef
	});
}
function goToLine(view, line, column = 1) {
	if (!view) return;
	const ln = Math.min(Math.max(1, line), view.state.doc.lines);
	const row = view.state.doc.line(ln);
	const pos = Math.min(row.to, row.from + Math.max(0, column - 1));
	view.dispatch({
		selection: { anchor: pos },
		scrollIntoView: true
	});
	view.focus();
}
function PythonTerminal({ className }) {
	const lines = useIdeStore((s) => s.lines);
	const stdin = useIdeStore((s) => s.stdin);
	const setStdin = useIdeStore((s) => s.setStdin);
	const replDraft = useIdeStore((s) => s.replDraft);
	const setReplDraft = useIdeStore((s) => s.setReplDraft);
	const settings = useIdeStore((s) => s.settings);
	const clearTerminal = useIdeStore((s) => s.clearTerminal);
	const status = useIdeStore((s) => s.status);
	const scroller = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		scroller.current?.scrollTo({ top: scroller.current.scrollHeight });
	}, [lines]);
	const onRepl = (e) => {
		if (e.key !== "Enter" || status === "running" || status === "loading") return;
		const cmd = replDraft.trim();
		if (!cmd) return;
		useIdeStore.getState().appendLine({
			kind: "in",
			text: `>>> ${cmd}`
		});
		setReplDraft("");
		window.dispatchEvent(new CustomEvent("zhina-repl", { detail: cmd }));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cn("flex min-h-0 flex-col", className),
		style: {
			background: settings.terminalBg,
			color: settings.terminalFg,
			fontFamily: settings.fontFamily,
			fontSize: `${Math.max(12, settings.fontSize - 1)}px`,
			fontWeight: settings.fontWeight,
			fontStyle: settings.fontStyle
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex h-10 shrink-0 items-center justify-between gap-2 border-t border-border px-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-muted uppercase",
					children: "Terminal"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						size: "icon",
						variant: "ghost",
						className: "size-9",
						"aria-label": "Copy output",
						onClick: () => {
							const text = lines.filter((l) => l.kind !== "image").map((l) => l.text).join("\n");
							navigator.clipboard?.writeText(text);
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						size: "icon",
						variant: "ghost",
						className: "size-9",
						"aria-label": "Clear terminal",
						onClick: clearTerminal,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: scroller,
				className: "min-h-0 flex-1 overflow-auto px-3 pb-2",
				children: lines.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pt-2 text-sm",
					style: { color: settings.terminalPrompt },
					children: "Output appears here. Type below to use the interactive shell."
				}) : lines.map((line) => line.kind === "image" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: `data:image/png;base64,${line.text}`,
					alt: "Plot output",
					className: "my-2 max-w-full rounded-md outline outline-1 -outline-offset-1 outline-black/10"
				}, line.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "whitespace-pre-wrap break-words leading-relaxed",
					style: { color: line.kind === "stderr" ? settings.terminalErr : line.kind === "in" || line.kind === "system" ? settings.terminalPrompt : settings.terminalFg },
					children: line.text
				}, line.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "shrink-0 border-t border-border px-3 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "mb-1 block text-[11px] tracking-wide text-muted uppercase",
						children: "Program input"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: stdin,
						onChange: (e) => setStdin(e.target.value),
						rows: 2,
						placeholder: "Lines read by input(), one per line",
						className: "mb-2 w-full resize-none rounded-lg border-0 bg-black/20 px-2 py-1.5 text-sm outline-none",
						style: { color: settings.terminalFg }
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "select-none",
							style: { color: settings.terminalPrompt },
							children: ">>>"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: replDraft,
							onChange: (e) => setReplDraft(e.target.value),
							onKeyDown: onRepl,
							placeholder: "Interactive shell",
							className: "h-10 min-w-0 flex-1 border-0 bg-transparent text-sm outline-none",
							style: { color: settings.terminalFg },
							autoCapitalize: "off",
							autoCorrect: "off",
							spellCheck: false
						})]
					})
				]
			})
		]
	});
}
function RunFab({ keyboardInset = 0 }) {
	const status = useIdeStore((s) => s.status);
	const running = status === "running";
	const loading = status === "loading";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		type: "button",
		size: "fab",
		className: cn("fixed z-40", running ? "bg-danger text-fg" : "bg-accent text-accent-fg", loading && !running ? "opacity-80" : ""),
		style: {
			right: "max(1rem, env(safe-area-inset-right))",
			bottom: `calc(${keyboardInset}px + 3.25rem + ${keyboardInset > 0 ? "0px" : "env(safe-area-inset-bottom)"} + 0.75rem)`
		},
		"aria-label": running ? "Stop" : loading ? "Loading Python — tap to queue a run" : "Run",
		onClick: () => {
			window.dispatchEvent(new CustomEvent(running ? "zhina-stop" : "zhina-run"));
		},
		children: running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-5 fill-current" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
			className: "size-6 fill-current",
			style: { marginLeft: 2 }
		})
	});
}
function VolumeRocker({ viewRef }) {
	const enabled = useIdeStore((s) => s.settings.volumeCursor);
	const timer = (0, import_react.useRef)(null);
	if (!enabled) return null;
	const hold = (dir) => {
		const step = () => {
			if (viewRef.current) moveCursor(viewRef.current, dir);
		};
		step();
		const id = window.setTimeout(() => {
			timer.current = window.setInterval(step, 70);
		}, 380);
		const stop = () => {
			window.clearTimeout(id);
			if (timer.current) window.clearInterval(timer.current);
			timer.current = null;
			window.removeEventListener("pointerup", stop);
			window.removeEventListener("pointercancel", stop);
		};
		window.addEventListener("pointerup", stop);
		window.addEventListener("pointercancel", stop);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-auto absolute top-[28%] right-1 z-30 flex flex-col items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex w-11 flex-col overflow-hidden rounded-xl bg-elevated shadow-[var(--shadow-border),var(--shadow-lift)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "bg-surface py-1 text-center text-[9px] font-medium tracking-widest text-muted uppercase",
					children: "Vol"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "flex h-12 items-center justify-center text-fg active:bg-surface",
					"aria-label": "Volume up — move cursor up",
					onPointerDown: (e) => {
						e.preventDefault();
						e.stopPropagation();
						hold("up");
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "size-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-px bg-border" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "flex h-12 items-center justify-center text-fg active:bg-surface",
					"aria-label": "Volume down — move cursor down",
					onPointerDown: (e) => {
						e.preventDefault();
						e.stopPropagation();
						hold("down");
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-5" })
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex overflow-hidden rounded-xl bg-elevated shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "flex size-11 items-center justify-center text-fg active:bg-surface",
					"aria-label": "Move cursor left",
					onPointerDown: (e) => {
						e.preventDefault();
						hold("left");
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-px bg-border" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "flex size-11 items-center justify-center text-fg active:bg-surface",
					"aria-label": "Move cursor right",
					onPointerDown: (e) => {
						e.preventDefault();
						hold("right");
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
				})
			]
		})]
	});
}
function ErrorBanner({ viewRef }) {
	const lastError = useIdeStore((s) => s.lastError);
	const setLastError = useIdeStore((s) => s.setLastError);
	if (!lastError) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start gap-3 border-t border-danger/40 bg-danger/10 px-3 py-2.5 text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "mt-0.5 size-4 shrink-0 text-danger" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "min-w-0 flex-1 text-left",
				onClick: () => {
					if (lastError.line) goToLine(viewRef.current, lastError.line, lastError.column ?? 1);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm font-medium",
					children: [lastError.type, lastError.line ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "ml-2 font-normal text-muted",
						children: ["on line ", lastError.line]
					}) : null]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-0.5 text-sm text-fg/90",
					children: lastError.message
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				size: "icon",
				variant: "ghost",
				className: "size-8 shrink-0",
				"aria-label": "Dismiss error",
				onClick: () => setLastError(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
			})
		]
	});
}
function AnalysisStrip({ viewRef }) {
	const diagnostics = useIdeStore((s) => s.diagnostics);
	const cursor = useIdeStore((s) => s.cursor);
	const pythonVersion = useIdeStore((s) => s.pythonVersion);
	const status = useIdeStore((s) => s.status);
	const errors = diagnostics.filter((d) => d.severity === "error");
	const warnings = diagnostics.filter((d) => d.severity === "warning");
	const first = errors[0] ?? warnings[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-8 shrink-0 items-center gap-3 overflow-hidden border-t border-border bg-surface px-3 text-xs text-muted tabular-nums",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "truncate",
				children: status === "loading" ? "Loading interpreter" : pythonVersion
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
				"Ln ",
				cursor.line,
				", Col ",
				cursor.column
			] }),
			first ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "min-w-0 truncate text-left text-fg",
				onClick: () => goToLine(viewRef.current, first.line, first.column),
				children: [
					errors.length ? `${errors.length} error${errors.length === 1 ? "" : "s"}` : `${warnings.length} warning${warnings.length === 1 ? "" : "s"}`,
					": ",
					first.type,
					" on line ",
					first.line
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "truncate",
				children: "No issues · Tab accepts a suggestion"
			})
		]
	});
}
function Switch({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
		className: cn("peer inline-flex h-7 w-12 shrink-0 cursor-pointer items-center rounded-full border border-border bg-elevated transition-colors data-[state=checked]:bg-accent", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "pointer-events-none block size-5 translate-x-1 rounded-full bg-fg transition-transform data-[state=checked]:translate-x-6 data-[state=checked]:bg-accent-fg" })
	});
}
function Slider({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
		className: cn("relative flex w-full touch-none items-center select-none", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
			className: "relative h-1.5 w-full grow overflow-hidden rounded-full bg-elevated",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-accent" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-5 rounded-full bg-fg shadow-[var(--shadow-border)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent" })]
	});
}
async function requestPersistentStorage() {
	if (!("storage" in navigator) || !navigator.storage?.persist) return false;
	try {
		return await navigator.storage.persist();
	} catch {
		return false;
	}
}
async function storagePersisted() {
	if (!("storage" in navigator) || !navigator.storage?.persisted) return false;
	try {
		return await navigator.storage.persisted();
	} catch {
		return false;
	}
}
async function requestWakeLock() {
	try {
		const nav = navigator;
		if (!nav.wakeLock) return null;
		return await nav.wakeLock.request("screen");
	} catch {
		return null;
	}
}
function isStandalone() {
	if (typeof window === "undefined") return false;
	const mq = window.matchMedia("(display-mode: standalone)").matches;
	const ios = "standalone" in navigator && Boolean(navigator.standalone);
	return mq || ios;
}
function isAndroid() {
	if (typeof navigator === "undefined") return false;
	return /Android/i.test(navigator.userAgent);
}
var COLOR_FIELDS = [
	{
		key: "editorBg",
		label: "Editor background"
	},
	{
		key: "editorFg",
		label: "Editor text"
	},
	{
		key: "editorGutter",
		label: "Line numbers"
	},
	{
		key: "editorSelection",
		label: "Selection"
	},
	{
		key: "editorLine",
		label: "Current line"
	},
	{
		key: "editorBlock",
		label: "Block highlight"
	},
	{
		key: "editorGuide",
		label: "Block lines"
	},
	{
		key: "editorCursor",
		label: "Cursor"
	},
	{
		key: "editorComment",
		label: "Comments"
	},
	{
		key: "editorKeyword",
		label: "Keywords"
	},
	{
		key: "editorString",
		label: "Strings"
	},
	{
		key: "editorNumber",
		label: "Numbers"
	},
	{
		key: "editorFunction",
		label: "Functions"
	},
	{
		key: "terminalBg",
		label: "Terminal background"
	},
	{
		key: "terminalFg",
		label: "Terminal text"
	},
	{
		key: "terminalErr",
		label: "Terminal errors"
	},
	{
		key: "terminalPrompt",
		label: "Terminal prompt"
	}
];
function toPickerHex(value) {
	if (value.startsWith("#") && value.length >= 7) return value.slice(0, 7);
	const m = value.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/);
	if (!m) return "#888888";
	const h = (n) => Number(n).toString(16).padStart(2, "0");
	return `#${h(m[1] ?? "0")}${h(m[2] ?? "0")}${h(m[3] ?? "0")}`;
}
function SettingsScreen() {
	const settings = useIdeStore((s) => s.settings);
	const patch = useIdeStore((s) => s.patchSettings);
	const applyPreset = useIdeStore((s) => s.applyPreset);
	const layout = useIdeStore((s) => s.terminalLayout);
	const setLayout = useIdeStore((s) => s.setTerminalLayout);
	const setScreen = useIdeStore((s) => s.setScreen);
	const persistGranted = useIdeStore((s) => s.persistGranted);
	const setPersistGranted = useIdeStore((s) => s.setPersistGranted);
	const pythonVersion = useIdeStore((s) => s.pythonVersion);
	const standalone = isStandalone();
	const android = isAndroid();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh min-h-0 flex-col bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex h-12 shrink-0 items-center gap-2 border-b border-border px-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "ghost",
				size: "icon",
				"aria-label": "Back",
				onClick: () => setScreen("editor"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-5" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-base font-medium",
				children: "Settings"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-h-0 flex-1 overflow-y-auto px-4 py-5 pb-28",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
					title: "Theme",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2",
						children: Object.keys(THEME_PRESETS).map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => applyPreset(id),
							className: cn("h-11 rounded-xl px-3 text-left text-sm", settings.preset === id ? "bg-accent text-accent-fg" : "bg-elevated text-fg"),
							children: THEME_PRESETS[id].label
						}, id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Group, {
					title: "Font",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-sm text-muted",
							children: "Family"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 gap-2",
							children: FONT_FAMILIES.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => patch({ fontFamily: f.id }),
								className: cn("h-11 rounded-xl px-3 text-left text-sm", settings.fontFamily === f.id ? "bg-accent text-accent-fg" : "bg-elevated text-fg"),
								style: { fontFamily: f.id },
								children: f.label
							}, f.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex items-center justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm",
								children: [
									"Size ",
									settings.fontSize,
									"px"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								className: "max-w-48",
								min: 12,
								max: 22,
								step: 1,
								value: [settings.fontSize],
								onValueChange: (v) => patch({ fontSize: v[0] ?? 14 })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm text-muted",
							children: "Weight"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 flex gap-2",
							children: [
								"400",
								"500",
								"600",
								"700"
							].map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => patch({ fontWeight: w }),
								className: cn("h-11 flex-1 rounded-lg text-sm", settings.fontWeight === w ? "bg-accent text-accent-fg" : "bg-elevated"),
								children: w
							}, w))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Italic",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: settings.fontStyle === "italic",
								onCheckedChange: (c) => patch({ fontStyle: c ? "italic" : "normal" })
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
					title: "Colours",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 gap-2",
						children: COLOR_FIELDS.map((field) => {
							const hex = toPickerHex(String(settings[field.key] ?? ""));
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex h-12 items-center justify-between gap-3 rounded-xl bg-elevated px-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm",
									children: field.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-xs text-muted",
										children: hex
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "color",
										value: hex,
										onChange: (e) => patch({ [field.key]: e.target.value }),
										className: "size-9 cursor-pointer rounded border-0 bg-transparent"
									})]
								})]
							}, field.key);
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Group, {
					title: "Layout",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-sm text-muted",
							children: "Where the terminal lives"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: cn("h-11 rounded-xl text-sm", layout === "below" ? "bg-accent text-accent-fg" : "bg-elevated"),
								onClick: () => setLayout("below"),
								children: "Under the editor"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: cn("h-11 rounded-xl text-sm", layout === "screen" ? "bg-accent text-accent-fg" : "bg-elevated"),
								onClick: () => setLayout("screen"),
								children: "Own screen"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Block lines",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: settings.showBlockLines,
								onCheckedChange: (c) => patch({ showBlockLines: c })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Word wrap",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: settings.wordWrap,
								onCheckedChange: (c) => patch({ wordWrap: c })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex items-center justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm",
								children: ["Tab size ", settings.tabSize]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
								className: "max-w-40",
								min: 2,
								max: 8,
								step: 2,
								value: [settings.tabSize],
								onValueChange: (v) => patch({ tabSize: v[0] ?? 4 })
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Group, {
					title: "Cursor",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Volume buttons move cursor",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: settings.volumeCursor,
							onCheckedChange: (c) => patch({ volumeCursor: c })
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted",
						children: "The Vol pad on the right moves the caret. Volume up goes up a line, volume down goes down. Hardware volume keys are used when the phone sends them. On a computer, Alt+Up and Alt+Down do the same."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Group, {
					title: "Permissions",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-3 text-sm leading-relaxed text-muted",
							children: "Zhina saves your code on this device. Persistent storage keeps it if the browser wants to free space."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: persistGranted ? "secondary" : "default",
							onClick: async () => {
								const ok = await requestPersistentStorage();
								setPersistGranted(ok);
							},
							children: persistGranted ? "Storage allowed" : "Allow persistent storage"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-4 space-y-2 text-sm text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Clipboard — used when you copy output" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Wake lock — screen can stay awake while a program runs" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Files — only when you open or download a .py file" })
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Group, {
					title: "Android install",
					children: [standalone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-relaxed",
						children: "Running as an installed app."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
						className: "list-decimal space-y-2 pl-5 text-sm leading-relaxed text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Open Zhina Python in Chrome on Android." }),
							android ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Tap the menu, then Add to Home screen / Install app." }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Chrome menu → Add to Home screen." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Open the icon for a full-screen interpreter." })
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstallButton, {})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Group, {
					title: "About",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm leading-relaxed text-muted",
						children: [pythonVersion, " via Pyodide. Standard library is included. Extra packages load from the Pyodide build or PyPI (Libraries)."]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						className: "mt-3",
						onClick: () => useIdeStore.getState().resetSettings(),
						children: "Reset settings"
					})]
				})
			]
		})]
	});
}
function Group({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mb-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-3 text-xs font-medium tracking-wide text-muted uppercase",
			children: title
		}), children]
	});
}
function Row({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 flex min-h-11 items-center justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm",
			children: label
		}), children]
	});
}
function InstallButton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		type: "button",
		variant: "secondary",
		className: "mt-4",
		onClick: () => {
			window.dispatchEvent(new CustomEvent("zhina-install-app"));
		},
		children: "Install app"
	});
}
function pypi(name) {
	return `https://pypi.org/project/${name}/`;
}
function stdlibDocs(mod) {
	return `https://docs.python.org/3/library/${mod}.html`;
}
var STDLIB_MODULES = [
	["math", "Mathematical functions"],
	["random", "Random numbers"],
	["statistics", "Mean, median, variance"],
	["datetime", "Dates and times"],
	["time", "Clocks and sleep"],
	["json", "JSON encode and decode"],
	["re", "Regular expressions"],
	["os", "Operating system interface (limited in the browser)"],
	["sys", "Interpreter state"],
	["pathlib", "Object-oriented paths"],
	["collections", "Deque, Counter, defaultdict"],
	["itertools", "Iterators and combinatorics"],
	["functools", "lru_cache, reduce, partial"],
	["typing", "Type hints"],
	["dataclasses", "Data classes"],
	["enum", "Enumerations"],
	["copy", "Shallow and deep copy"],
	["csv", "CSV reader and writer"],
	["io", "In-memory streams"],
	["base64", "Base64 encoding"],
	["hashlib", "Hashes"],
	["html", "HTML escaping"],
	["textwrap", "Wrap and fill text"],
	["string", "String constants and Template"],
	["decimal", "Decimal arithmetic"],
	["fractions", "Rational numbers"],
	["pprint", "Pretty printers"],
	["unittest", "Unit testing"],
	["doctest", "Docstring tests"],
	["argparse", "Command-line parsing"],
	["logging", "Logging"],
	["traceback", "Print traces"],
	["ast", "Abstract syntax trees"],
	["inspect", "Live object inspection"],
	["operator", "Function equivalents of operators"],
	["abc", "Abstract base classes"],
	["contextlib", "Context managers"],
	["calendar", "Calendars"],
	["zoneinfo", "IANA time zones"],
	["unicodedata", "Unicode database"],
	["urllib.parse", "URL parsing"]
].map(([name, summary]) => ({
	name,
	kind: "stdlib",
	summary,
	docsUrl: stdlibDocs(name.split(".")[0] ?? name),
	pypiUrl: pypi(name.split(".")[0] ?? name)
}));
/** Packages Pyodide can load with loadPackage / loadPackagesFromImports. */
var BUNDLED_PACKAGES = [
	{
		name: "numpy",
		kind: "bundled",
		summary: "Arrays and numerical computing",
		docsUrl: "https://numpy.org/doc/stable/",
		pypiUrl: pypi("numpy")
	},
	{
		name: "pandas",
		kind: "bundled",
		summary: "Data frames and analysis",
		docsUrl: "https://pandas.pydata.org/docs/",
		pypiUrl: pypi("pandas")
	},
	{
		name: "matplotlib",
		kind: "bundled",
		summary: "Charts and plots",
		docsUrl: "https://matplotlib.org/stable/",
		pypiUrl: pypi("matplotlib")
	},
	{
		name: "scipy",
		kind: "bundled",
		summary: "Scientific computing",
		docsUrl: "https://docs.scipy.org/doc/scipy/",
		pypiUrl: pypi("scipy")
	},
	{
		name: "scikit-learn",
		kind: "bundled",
		summary: "Machine learning",
		docsUrl: "https://scikit-learn.org/stable/",
		pypiUrl: pypi("scikit-learn")
	},
	{
		name: "pillow",
		kind: "bundled",
		summary: "Image processing (PIL)",
		docsUrl: "https://pillow.readthedocs.io/",
		pypiUrl: pypi("pillow")
	},
	{
		name: "sympy",
		kind: "bundled",
		summary: "Symbolic math",
		docsUrl: "https://docs.sympy.org/",
		pypiUrl: pypi("sympy")
	},
	{
		name: "networkx",
		kind: "bundled",
		summary: "Graphs and networks",
		docsUrl: "https://networkx.org/documentation/stable/",
		pypiUrl: pypi("networkx")
	},
	{
		name: "regex",
		kind: "bundled",
		summary: "Advanced regular expressions",
		docsUrl: "https://github.com/mrabarnett/mrab-regex",
		pypiUrl: pypi("regex")
	},
	{
		name: "pyyaml",
		kind: "bundled",
		summary: "YAML parser",
		docsUrl: "https://pyyaml.org/",
		pypiUrl: pypi("pyyaml")
	},
	{
		name: "beautifulsoup4",
		kind: "bundled",
		summary: "HTML / XML parsing",
		docsUrl: "https://www.crummy.com/software/BeautifulSoup/bs4/doc/",
		pypiUrl: pypi("beautifulsoup4")
	},
	{
		name: "lxml",
		kind: "bundled",
		summary: "Fast XML / HTML",
		docsUrl: "https://lxml.de/",
		pypiUrl: pypi("lxml")
	}
];
var SUGGESTED_PYPI = [{
	name: "cowsay",
	kind: "pypi",
	summary: "Tiny example of a pure-Python package",
	docsUrl: pypi("cowsay"),
	pypiUrl: pypi("cowsay")
}, {
	name: "pydantic",
	kind: "pypi",
	summary: "Data validation (pure Python parts)",
	docsUrl: "https://docs.pydantic.dev/",
	pypiUrl: pypi("pydantic")
}];
var PYPI_SEARCH = "https://pypi.org/search/?q=";
var PYPI_HOME = "https://pypi.org/";
function pypiProjectUrl(name) {
	const slug = name.trim().toLowerCase().replace(/_/g, "-");
	return `https://pypi.org/project/${encodeURIComponent(slug)}/`;
}
function LibrariesScreen() {
	const setScreen = useIdeStore((s) => s.setScreen);
	const status = useIdeStore((s) => s.status);
	const [query, setQuery] = (0, import_react.useState)("");
	const [custom, setCustom] = (0, import_react.useState)("");
	const q = query.trim().toLowerCase();
	const stdlib = (0, import_react.useMemo)(() => STDLIB_MODULES.filter((p) => !q || p.name.includes(q) || p.summary.toLowerCase().includes(q)), [q]);
	const bundled = (0, import_react.useMemo)(() => BUNDLED_PACKAGES.filter((p) => !q || p.name.includes(q) || p.summary.toLowerCase().includes(q)), [q]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh min-h-0 flex-col bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex h-12 shrink-0 items-center gap-2 border-b border-border px-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "ghost",
				size: "icon",
				"aria-label": "Back",
				onClick: () => setScreen("editor"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-5" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-base font-medium",
				children: "Libraries"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-h-0 flex-1 overflow-auto px-4 py-5 pb-28",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm leading-relaxed text-muted",
					children: [
						"The Python standard library is already here. Scientific packages ship with the interpreter and load on first import. Everything else is installed from",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "text-fg underline decoration-border underline-offset-2",
							href: PYPI_HOME,
							target: "_blank",
							rel: "noreferrer",
							children: "PyPI"
						}),
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: query,
					onChange: (e) => setQuery(e.target.value),
					placeholder: "Filter libraries",
					className: "mt-4 h-11 w-full rounded-xl bg-elevated px-3 text-sm text-fg outline-none"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-8 mb-3 text-xs font-medium tracking-wide text-muted uppercase",
					children: "Preinstalled (stdlib)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col gap-2",
					children: stdlib.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LibRow, { lib: p }, p.name))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-8 mb-3 text-xs font-medium tracking-wide text-muted uppercase",
					children: "Included scientific packages"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col gap-2",
					children: bundled.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LibRow, {
						lib: p,
						action: "Load",
						disabled: status === "running" || status === "loading",
						onAction: () => window.dispatchEvent(new CustomEvent("zhina-install-package", { detail: p.name }))
					}, p.name))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-8 mb-3 text-xs font-medium tracking-wide text-muted uppercase",
					children: "Download from PyPI"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-sm text-muted",
					children: "Search the index, then install a wheel. Pure-Python packages work best in the browser."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: custom,
							onChange: (e) => setCustom(e.target.value),
							placeholder: "Package name, e.g. cowsay",
							className: "h-11 min-w-0 flex-1 rounded-xl bg-elevated px-3 text-sm text-fg outline-none"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "secondary",
							disabled: !custom.trim(),
							onClick: () => window.open(`${PYPI_SEARCH}${encodeURIComponent(custom.trim())}`, "_blank"),
							children: "PyPI"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							disabled: !custom.trim() || status === "running",
							onClick: () => window.dispatchEvent(new CustomEvent("zhina-install-package", { detail: custom.trim() })),
							children: "Install"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 flex flex-col gap-2",
					children: SUGGESTED_PYPI.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LibRow, {
						lib: p,
						action: "Install",
						onAction: () => window.dispatchEvent(new CustomEvent("zhina-install-package", { detail: p.name }))
					}, p.name))
				})
			]
		})]
	});
}
function LibRow({ lib, action, onAction, disabled }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3 rounded-xl bg-elevated px-3 py-2.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate font-mono text-sm",
					children: lib.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-xs text-muted",
					children: lib.summary
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: lib.kind === "stdlib" ? lib.docsUrl : pypiProjectUrl(lib.name),
				target: "_blank",
				rel: "noreferrer",
				className: "inline-flex size-9 items-center justify-center rounded-lg text-muted hover:text-fg",
				"aria-label": `Open ${lib.name} docs`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-4" })
			}),
			action && onAction ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				size: "sm",
				variant: "secondary",
				disabled,
				onClick: onAction,
				children: action
			}) : null
		]
	});
}
function HintBanner() {
	const dismissed = useIdeStore((s) => s.hintDismissed);
	const dismiss = useIdeStore((s) => s.dismissHint);
	if (dismissed) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start gap-2 border-b border-border bg-elevated px-3 py-2 text-sm text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "min-w-0 flex-1 leading-relaxed",
			children: "Tap Run to execute. The key bar above the keyboard inserts brackets and quotes. Recent files sit under the title. Vol pad moves the cursor."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			type: "button",
			variant: "ghost",
			size: "icon",
			className: "size-9 shrink-0",
			"aria-label": "Dismiss",
			onClick: dismiss,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
		})]
	});
}
function RecentFiles() {
	const files = useIdeStore((s) => s.files);
	const activeFileId = useIdeStore((s) => s.activeFileId);
	const openFile = useIdeStore((s) => s.openFile);
	const closeFile = useIdeStore((s) => s.closeFile);
	const newFile = useIdeStore((s) => s.newFile);
	const renameFile = useIdeStore((s) => s.renameFile);
	const [editingId, setEditingId] = (0, import_react.useState)(null);
	const [draft, setDraft] = (0, import_react.useState)("");
	const startRename = (file) => {
		setEditingId(file.id);
		setDraft(file.name.replace(/\.py$/i, ""));
	};
	const commitRename = () => {
		if (editingId && draft.trim()) renameFile(editingId, draft.trim());
		setEditingId(null);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-11 shrink-0 items-center gap-1 border-b border-border bg-surface px-1.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "hidden shrink-0 px-1.5 text-[10px] font-medium tracking-wide text-muted uppercase sm:block",
				children: "Recent"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex min-w-0 flex-1 items-center gap-1 overflow-x-auto py-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden",
				children: files.map((file) => {
					const active = file.id === activeFileId;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("flex h-8 max-w-[11rem] shrink-0 items-center rounded-lg pl-2.5", active ? "bg-accent text-accent-fg" : "bg-elevated text-fg"),
						children: [editingId === file.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: draft,
							autoFocus: true,
							"aria-label": "Rename file",
							className: "h-7 w-24 bg-transparent text-xs outline-none",
							onChange: (e) => setDraft(e.target.value),
							onBlur: commitRename,
							onKeyDown: (e) => {
								if (e.key === "Enter") commitRename();
								if (e.key === "Escape") setEditingId(null);
							}
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-w-0 truncate font-mono text-xs",
							title: file.name,
							onClick: () => active ? startRename(file) : openFile(file.id),
							children: file.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: cn("flex size-8 shrink-0 items-center justify-center rounded-md", active ? "text-accent-fg/80" : "text-muted"),
							"aria-label": `Close ${file.name}`,
							onClick: (e) => {
								e.stopPropagation();
								closeFile(file.id);
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
						})]
					}, file.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "flex size-9 shrink-0 items-center justify-center rounded-lg text-fg hover:bg-elevated",
				"aria-label": "New file",
				onClick: () => newFile(),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
			})
		]
	});
}
var PAIRS = {
	"(": ")",
	"[": "]",
	"{": "}",
	"\"": "\"",
	"'": "'",
	"`": "`",
	"f\"": "\""
};
function insertIntoField(el, text) {
	const close = PAIRS[text] ?? "";
	const start = el.selectionStart ?? el.value.length;
	const end = el.selectionEnd ?? start;
	const selected = el.value.slice(start, end);
	const chunk = close && selected ? `${text}${selected}${close}` : close ? `${text}${close}` : text;
	el.value = el.value.slice(0, start) + chunk + el.value.slice(end);
	const caret = start + (close && !selected ? text.length : chunk.length);
	el.setSelectionRange(caret, caret);
	el.dispatchEvent(new Event("input", { bubbles: true }));
	el.focus();
}
function insertText(view, text) {
	const active = document.activeElement;
	if (active instanceof HTMLInputElement || active instanceof HTMLTextAreaElement) {
		insertIntoField(active, text);
		return;
	}
	if (!view) return;
	const close = PAIRS[text];
	const sel = view.state.selection.main;
	if (close && sel.from !== sel.to) {
		const wrapped = `${text}${view.state.sliceDoc(sel.from, sel.to)}${close}`;
		view.dispatch({
			changes: {
				from: sel.from,
				to: sel.to,
				insert: wrapped
			},
			selection: { anchor: sel.from + wrapped.length },
			scrollIntoView: true
		});
	} else if (close) view.dispatch({
		changes: {
			from: sel.from,
			to: sel.to,
			insert: text + close
		},
		selection: { anchor: sel.from + text.length },
		scrollIntoView: true
	});
	else view.dispatch({
		changes: {
			from: sel.from,
			to: sel.to,
			insert: text
		},
		selection: { anchor: sel.from + text.length },
		scrollIntoView: true
	});
	view.focus();
}
function runEditorCommand(view, name) {
	if (!view) return;
	(name === "tab" ? indentMore : name === "untab" ? indentLess : name === "undo" ? undo : redo)(view);
	view.focus();
}
var KEYS = [
	{
		kind: "cmd",
		label: "Tab",
		cmd: "tab",
		wide: true
	},
	{
		kind: "text",
		label: "(",
		insert: "("
	},
	{
		kind: "text",
		label: ")",
		insert: ")"
	},
	{
		kind: "text",
		label: "[",
		insert: "["
	},
	{
		kind: "text",
		label: "]",
		insert: "]"
	},
	{
		kind: "text",
		label: "{",
		insert: "{"
	},
	{
		kind: "text",
		label: "}",
		insert: "}"
	},
	{
		kind: "text",
		label: "\"",
		insert: "\""
	},
	{
		kind: "text",
		label: "'",
		insert: "'"
	},
	{
		kind: "text",
		label: ":",
		insert: ":"
	},
	{
		kind: "text",
		label: ",",
		insert: ","
	},
	{
		kind: "text",
		label: ".",
		insert: "."
	},
	{
		kind: "text",
		label: "=",
		insert: "="
	},
	{
		kind: "text",
		label: "+",
		insert: "+"
	},
	{
		kind: "text",
		label: "-",
		insert: "-"
	},
	{
		kind: "text",
		label: "*",
		insert: "*"
	},
	{
		kind: "text",
		label: "/",
		insert: "/"
	},
	{
		kind: "text",
		label: "#",
		insert: "#"
	},
	{
		kind: "text",
		label: "_",
		insert: "_"
	},
	{
		kind: "text",
		label: "\\",
		insert: "\\"
	},
	{
		kind: "text",
		label: "<",
		insert: "<"
	},
	{
		kind: "text",
		label: ">",
		insert: ">"
	},
	{
		kind: "text",
		label: "->",
		insert: " -> "
	},
	{
		kind: "text",
		label: "f\"",
		insert: "f\""
	},
	{ kind: "complete" },
	{
		kind: "cmd",
		label: "undo",
		cmd: "undo"
	},
	{
		kind: "cmd",
		label: "redo",
		cmd: "redo"
	},
	{
		kind: "move",
		label: "left",
		dir: "left"
	},
	{
		kind: "move",
		label: "right",
		dir: "right"
	},
	{ kind: "backspace" }
];
function SymbolBar({ viewRef, keyboardInset = 0 }) {
	const press = (action) => (e) => {
		e.preventDefault();
		action();
	};
	const run = (spec) => {
		const view = viewRef.current;
		if (spec.kind === "text") {
			insertText(view, spec.insert);
			return;
		}
		if (!view) return;
		if (spec.kind === "cmd") runEditorCommand(view, spec.cmd);
		else if (spec.kind === "move") moveCursor(view, spec.dir);
		else if (spec.kind === "complete") {
			startCompletion(view);
			view.focus();
		} else if (spec.kind === "backspace") {
			const sel = view.state.selection.main;
			const from = sel.from === sel.to ? Math.max(0, sel.from - 1) : sel.from;
			view.dispatch({
				changes: {
					from,
					to: sel.to
				},
				selection: { anchor: from },
				scrollIntoView: true
			});
			view.focus();
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "z-30 flex min-h-[52px] shrink-0 items-center gap-1 overflow-x-auto border-t border-border bg-surface px-1.5 touch-manipulation [scrollbar-width:none] [&::-webkit-scrollbar]:hidden",
		style: { paddingBottom: keyboardInset > 0 ? 0 : "env(safe-area-inset-bottom)" },
		"aria-label": "Coding keys",
		children: KEYS.map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: cn("flex h-10 shrink-0 items-center justify-center rounded-lg bg-elevated font-mono text-sm text-fg active:bg-accent active:text-accent-fg", key.kind === "cmd" && key.wide ? "min-w-12 px-2.5 text-xs" : "min-w-10", key.kind === "complete" ? "min-w-14 px-2 text-xs" : ""),
			"aria-label": ariaFor(key),
			onPointerDown: press(() => run(key)),
			children: labelFor(key)
		}, key.kind === "text" ? `t-${key.label}` : key.kind === "cmd" ? `c-${key.cmd}` : key.kind === "move" ? `m-${key.dir}` : key.kind))
	});
}
function labelFor(key) {
	if (key.kind === "cmd" && key.cmd === "undo") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, { className: "size-4" });
	if (key.kind === "cmd" && key.cmd === "redo") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Redo2, { className: "size-4" });
	if (key.kind === "move" && key.dir === "left") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" });
	if (key.kind === "move" && key.dir === "right") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" });
	if (key.kind === "backspace") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Delete, { className: "size-4" });
	if (key.kind === "complete") return "abc";
	if (key.kind === "cmd") return key.label;
	return key.label;
}
function ariaFor(key) {
	if (key.kind === "text") return `Insert ${key.label}`;
	if (key.kind === "cmd") return key.cmd === "tab" ? "Indent" : key.cmd;
	if (key.kind === "move") return `Cursor ${key.dir}`;
	if (key.kind === "complete") return "Suggestions";
	return "Backspace";
}
function analyzeWithLezer(code) {
	const diagnostics = [];
	if (!code.trim()) return diagnostics;
	parser.parse(code).iterate({ enter(node) {
		if (node.type.isError) diagnostics.push({
			from: node.from,
			to: Math.max(node.to, node.from + 1),
			line: lineAt(code, node.from),
			column: colAt(code, node.from),
			severity: "error",
			type: "SyntaxError",
			message: "Invalid syntax"
		});
	} });
	const lines = code.split("\n");
	let previousIndent = 0;
	lines.forEach((text, i) => {
		if (!text.trim() || text.trim().startsWith("#")) return;
		const indent = text.match(/^[ \t]*/)?.[0] ?? "";
		if (indent.includes(" ") && indent.includes("	")) diagnostics.push({
			from: offsetAt(code, i + 1, 1),
			to: offsetAt(code, i + 1, indent.length + 1),
			line: i + 1,
			column: 1,
			severity: "error",
			type: "TabError",
			message: "Inconsistent use of tabs and spaces in indentation"
		});
		const n = indent.replace(/\t/g, "    ").length;
		if (n > previousIndent + 8 && previousIndent > 0) diagnostics.push({
			from: offsetAt(code, i + 1, 1),
			to: offsetAt(code, i + 1, 2),
			line: i + 1,
			column: 1,
			severity: "warning",
			type: "IndentationWarning",
			message: "Unexpected jump in indentation"
		});
		previousIndent = n;
	});
	for (const m of code.matchAll(/^(?:import|from)\s+([A-Za-z_][\w.]*)/gm)) {
		const imported = (m[1] ?? "").split(".")[0];
		if (imported && !nameUsedOutsideImport(code, imported)) diagnostics.push({
			from: m.index ?? 0,
			to: (m.index ?? 0) + m[0].length,
			line: lineAt(code, m.index ?? 0),
			column: 1,
			severity: "warning",
			type: "UnusedImport",
			message: `Imported '${imported}' is never used`
		});
	}
	return unique(diagnostics);
}
function nameUsedOutsideImport(code, name) {
	const re = new RegExp(`\\b${name}\\b`, "g");
	return [...code.matchAll(re)].length > 1;
}
function lineAt(code, index) {
	return code.slice(0, index).split("\n").length;
}
function colAt(code, index) {
	return index - (code.lastIndexOf("\n", index - 1) + 1) + 1;
}
function offsetAt(code, line, column) {
	const lines = code.split("\n");
	let off = 0;
	for (let i = 0; i < line - 1; i++) off += (lines[i]?.length ?? 0) + 1;
	return off + Math.max(0, column - 1);
}
function unique(items) {
	const seen = /* @__PURE__ */ new Set();
	return items.filter((d) => {
		const key = `${d.line}:${d.type}:${d.message}`;
		if (seen.has(key)) return false;
		seen.add(key);
		return true;
	});
}
var TYPE_RE = /([A-Za-z_][A-Za-z0-9_]*(?:Error|Exception|Warning|Exit|Interrupt))\s*:/;
var FILE_LINE_RE = /File ".*?", line (\d+)/g;
var SYNTAX_LINE_RE = /File ".*?", line (\d+)/;
function parsePythonError(raw) {
	const text = raw.replace(/^PythonError:\s*/i, "").trim();
	const type = text.match(TYPE_RE)?.[1] ?? "Error";
	let message = text;
	const lastType = text.lastIndexOf(`${type}:`);
	if (lastType >= 0) {
		message = text.slice(lastType + type.length + 1).trim();
		const nextNl = message.indexOf("\n");
		if (nextNl >= 0) message = message.slice(0, nextNl).trim();
	}
	let line = null;
	let column = null;
	const lines = [];
	for (const match of text.matchAll(FILE_LINE_RE)) {
		const n = Number(match[1]);
		if (Number.isFinite(n)) lines.push(n);
	}
	if (lines.length) line = lines[lines.length - 1] ?? null;
	const syntax = text.match(SYNTAX_LINE_RE);
	if (!line && syntax) line = Number(syntax[1]);
	const caretLine = text.split("\n").find((l) => l.includes("^"));
	if (caretLine && line) {
		const idx = caretLine.indexOf("^");
		if (idx >= 0) column = idx + 1;
	}
	if (type === "SyntaxError" || type === "IndentationError" || type === "TabError") {
		const syn = text.match(/line (\d+)/);
		if (syn) line = Number(syn[1]);
	}
	return {
		type,
		message: message || text.slice(0, 180),
		line,
		column,
		traceback: text
	};
}
var PythonRuntime = class {
	worker = null;
	handlers = /* @__PURE__ */ new Set();
	ready = false;
	version = "Python 3.14";
	subscribe(handler) {
		this.handlers.add(handler);
		return () => {
			this.handlers.delete(handler);
		};
	}
	emit(event) {
		for (const h of this.handlers) h(event);
	}
	spawn() {
		if (this.worker) {
			this.worker.terminate();
			this.worker = null;
		}
		this.ready = false;
		this.worker = new Worker(new URL("./worker.ts", import.meta.url), { type: "module" });
		this.worker.onmessage = (e) => {
			const ev = e.data;
			if (ev.type === "ready") {
				this.ready = true;
				this.version = ev.version;
			}
			this.emit(ev);
		};
		this.worker.onerror = (err) => {
			this.emit({
				type: "fatal",
				text: err.message || "Python worker failed"
			});
		};
		this.worker.postMessage({ type: "init" });
	}
	ensure() {
		if (!this.worker) this.spawn();
	}
	isReady() {
		return this.ready;
	}
	run(code, stdin) {
		this.ensure();
		this.worker?.postMessage({
			type: "run",
			code,
			stdin
		});
	}
	repl(code) {
		this.ensure();
		this.worker?.postMessage({
			type: "repl",
			code
		});
	}
	analyze(code) {
		const local = analyzeWithLezer(code);
		this.emit({
			type: "analysis",
			diagnostics: local
		});
		if (this.ready) this.worker?.postMessage({
			type: "analyze",
			code
		});
	}
	install(name) {
		this.ensure();
		this.worker?.postMessage({
			type: "install",
			name
		});
	}
	stop() {
		if (this.worker) {
			this.worker.terminate();
			this.worker = null;
			this.ready = false;
			this.emit({
				type: "stderr",
				text: "\nInterrupted.\n"
			});
			this.emit({
				type: "done",
				ok: false
			});
			this.emit({
				type: "status",
				status: "loading",
				detail: "Restarting interpreter"
			});
			this.spawn();
		}
	}
};
var pythonRuntime = new PythonRuntime();
function readKeyboardInset() {
	if (typeof window === "undefined") return 0;
	const vv = window.visualViewport;
	if (!vv) return 0;
	const inset = Math.max(0, window.innerHeight - vv.height - vv.offsetTop);
	return inset > 40 ? Math.round(inset) : 0;
}
function useKeyboardInset() {
	const [inset, setInset] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const apply = () => {
			const next = readKeyboardInset();
			setInset(next);
			document.documentElement.style.setProperty("--zhina-kb", `${next}px`);
		};
		apply();
		const vv = window.visualViewport;
		vv?.addEventListener("resize", apply);
		vv?.addEventListener("scroll", apply);
		window.addEventListener("resize", apply);
		window.addEventListener("focusin", apply);
		window.addEventListener("focusout", apply);
		return () => {
			vv?.removeEventListener("resize", apply);
			vv?.removeEventListener("scroll", apply);
			window.removeEventListener("resize", apply);
			window.removeEventListener("focusin", apply);
			window.removeEventListener("focusout", apply);
		};
	}, []);
	return inset;
}
function IdeApp() {
	const viewRef = (0, import_react.useRef)(null);
	const screen = useIdeStore((s) => s.screen);
	const layout = useIdeStore((s) => s.terminalLayout);
	const hydrated = useIdeStore((s) => s.hydrated);
	const kbInset = useKeyboardInset();
	const [deferredPrompt, setDeferredPrompt] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const finish = () => useIdeStore.getState().setHydrated();
		const unsub = useIdeStore.persist.onFinishHydration(finish);
		useIdeStore.persist.rehydrate();
		if (useIdeStore.persist.hasHydrated()) finish();
		const fallback = window.setTimeout(finish, 400);
		return () => {
			unsub();
			window.clearTimeout(fallback);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const unsub = pythonRuntime.subscribe((ev) => {
			const store = useIdeStore.getState();
			if (ev.type === "status") store.setStatus(ev.status, ev.detail);
			else if (ev.type === "ready") {
				store.setPythonVersion(ev.version);
				store.setStatus("ready");
			} else if (ev.type === "stdout") store.appendLine({
				kind: "stdout",
				text: ev.text
			});
			else if (ev.type === "stderr") store.appendLine({
				kind: "stderr",
				text: ev.text
			});
			else if (ev.type === "image") store.appendLine({
				kind: "image",
				text: ev.data
			});
			else if (ev.type === "python-error") {
				const parsed = parsePythonError(ev.text);
				store.setLastError(parsed);
				store.appendLine({
					kind: "stderr",
					text: ev.text
				});
				if (store.terminalLayout === "screen") store.setScreen("terminal");
			} else if (ev.type === "done") store.setStatus("ready");
			else if (ev.type === "analysis") {
				const local = analyzeWithLezer(store.code);
				const merged = [...ev.diagnostics];
				for (const d of local) if (!merged.some((m) => m.line === d.line && m.type === d.type)) merged.push(d);
				store.setDiagnostics(merged);
			} else if (ev.type === "installed") {
				if (ev.ok) {
					toast.success(`Installed ${ev.name}`);
					store.appendLine({
						kind: "system",
						text: `Installed ${ev.name}`
					});
				} else {
					toast.error(`Could not install ${ev.name}`);
					store.appendLine({
						kind: "stderr",
						text: `Install failed: ${ev.message ?? ev.name}\nTry a pure-Python wheel from https://pypi.org/project/${ev.name}/`
					});
				}
			} else if (ev.type === "fatal") {
				store.appendLine({
					kind: "stderr",
					text: ev.text
				});
				store.setStatus("error", ev.text);
			}
		});
		pythonRuntime.ensure();
		return unsub;
	}, []);
	(0, import_react.useEffect)(() => {
		let t;
		const runAnalyze = () => {
			const code = useIdeStore.getState().code;
			pythonRuntime.analyze(code);
		};
		t = window.setTimeout(runAnalyze, 500);
		const unsub = useIdeStore.subscribe((s, prev) => {
			if (s.code === prev.code) return;
			window.clearTimeout(t);
			t = window.setTimeout(runAnalyze, 450);
		});
		return () => {
			window.clearTimeout(t);
			unsub();
		};
	}, []);
	(0, import_react.useEffect)(() => {
		storagePersisted().then((ok) => {
			useIdeStore.getState().setPersistGranted(ok);
			if (!ok) requestPersistentStorage().then((g) => useIdeStore.getState().setPersistGranted(g));
		});
	}, []);
	(0, import_react.useEffect)(() => {
		const onRun = () => {
			const { code, stdin, terminalLayout, setScreen, clearTerminal, setLastError, appendLine, setStatus } = useIdeStore.getState();
			clearTerminal();
			setLastError(null);
			appendLine({
				kind: "system",
				text: "Running…"
			});
			setStatus("running");
			if (terminalLayout === "screen") setScreen("terminal");
			requestWakeLock();
			pythonRuntime.run(code, stdin);
		};
		const onStop = () => pythonRuntime.stop();
		const onRepl = (e) => {
			const cmd = e.detail;
			pythonRuntime.repl(cmd);
		};
		const onPkg = (e) => {
			const name = e.detail;
			if (!name) return;
			useIdeStore.getState().appendLine({
				kind: "system",
				text: `Installing ${name}…`
			});
			pythonRuntime.install(name);
		};
		window.addEventListener("zhina-run", onRun);
		window.addEventListener("zhina-stop", onStop);
		window.addEventListener("zhina-repl", onRepl);
		window.addEventListener("zhina-install-package", onPkg);
		return () => {
			window.removeEventListener("zhina-run", onRun);
			window.removeEventListener("zhina-stop", onStop);
			window.removeEventListener("zhina-repl", onRepl);
			window.removeEventListener("zhina-install-package", onPkg);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const onPrompt = (e) => {
			e.preventDefault();
			setDeferredPrompt(e);
		};
		window.addEventListener("beforeinstallprompt", onPrompt);
		const onInstall = () => {
			if (deferredPrompt) {
				deferredPrompt.prompt();
				setDeferredPrompt(null);
				return;
			}
			toast("Use the browser menu: Add to Home screen");
		};
		window.addEventListener("zhina-install-app", onInstall);
		return () => {
			window.removeEventListener("beforeinstallprompt", onPrompt);
			window.removeEventListener("zhina-install-app", onInstall);
		};
	}, [deferredPrompt]);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-dvh items-center justify-center bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Opening Zhina Python"
		})
	});
	if (screen === "settings") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsScreen, {});
	if (screen === "libraries") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LibrariesScreen, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex h-dvh flex-col overflow-hidden bg-bg text-fg",
		style: { paddingBottom: kbInset },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdeHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecentFiles, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HintBanner, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative flex min-h-0 flex-1 flex-col",
				children: [
					layout === "below" || screen === "editor" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex min-h-0 flex-1 flex-col",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PythonEditor, { viewRef }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeRocker, { viewRef })]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBanner, { viewRef }),
					layout === "below" || screen === "terminal" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PythonTerminal, { className: layout === "below" ? "h-[30%] max-h-[38%] min-h-[7.5rem] shrink-0" : "flex-1" }) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnalysisStrip, { viewRef }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SymbolBar, {
				viewRef,
				keyboardInset: kbInset
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RunFab, { keyboardInset: kbInset }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "top-center",
				toastOptions: { style: {
					background: "#232220",
					color: "#f0ede6",
					border: "1px solid #2e2c28"
				} }
			})
		]
	});
}
function Home() {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setMounted(true), []);
	if (!mounted) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex h-dvh items-center justify-center bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Zhina Python"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdeApp, {});
}
//#endregion
export { Home as component };
