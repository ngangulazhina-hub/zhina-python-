//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CcpPzTPg.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/settings"],
		preloads: ["/assets/index-CMz-cUtF.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CMz-cUtF.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CE5U49xT.js", "/assets/store-DW06ABIL.js"]
	},
	"/settings": {
		filePath: "/workspace/src/routes/settings.tsx",
		children: void 0,
		preloads: ["/assets/settings-cjae9X_G.js", "/assets/store-DW06ABIL.js"]
	}
} });
//#endregion
export { tsrStartManifest };
