import{a as e,o as t}from"./index-vcq64dg8.js";var n=t(e(),1),r=`# Welcome to Zhina Python
# A real Python interpreter that runs on this device.
# Press the Run button in the lower right to try it.

def greet(name: str) -> str:
    return f"Hello, {name} — welcome to Zhina."


print(greet("friend"))
print()

# Change the range, then run again.
for n in range(1, 6):
    print(f"{n} × {n} = {n * n}")

print()
print("Tips")
print("- Block lines follow indentation")
print("- Open Settings to change fonts and colours")
print("- Put the terminal on its own screen if you prefer")
`,i=[{id:`welcome`,title:`Welcome`,code:r},{id:`functions`,title:`Functions`,code:`def factorial(n: int) -> int:
    if n < 0:
        raise ValueError("n must be >= 0")
    result = 1
    for k in range(2, n + 1):
        result *= k
    return result


def describe(n: int) -> str:
    return f"{n}! = {factorial(n)}"


for value in (0, 1, 5, 8):
    print(describe(value))
`},{id:`errors`,title:`Error reporting`,code:`# Run this file to see how Zhina names the error and the line.
# Then fix it and run again.

def area(width, height):
    return width * height


print("3 × 4 =", area(3, 4))
print("10 × ? =", area(10, height))
`},{id:`input`,title:`Reading input`,code:`# Type answers in the Program input box (terminal), one line each,
# then press Run.

name = input("Your name: ")
times = int(input("How many times? "))

for i in range(times):
    print(f"{i + 1}. Nice to meet you, {name}.")
`},{id:`data`,title:`Lists and dicts`,code:`scores = {"Ada": 18, "Lin": 21, "Grace": 19}

print("Roster")
for name, score in sorted(scores.items()):
    bar = "■" * score
    print(f"  {name:8} {score:2}  {bar}")

average = sum(scores.values()) / len(scores)
print()
print(f"Average: {average:.1f}")
print("Top:", max(scores, key=scores.get))
`},{id:`chart`,title:`Chart (matplotlib)`,code:`import matplotlib.pyplot as plt

xs = list(range(0, 11))
ys = [x * x for x in xs]

fig, ax = plt.subplots(figsize=(6, 3.4))
ax.plot(xs, ys, color="#3d4a55", marker="o")
ax.set_title("Squares")
ax.set_xlabel("n")
ax.set_ylabel("n²")
ax.grid(True, alpha=0.3)
fig.tight_layout()
print("Chart drawn below.")
`}],a=e=>{let t,n=new Set,r=(e,r)=>{let i=typeof e==`function`?e(t):e;if(!Object.is(i,t)){let e=t;t=r??(typeof i!=`object`||!i)?i:Object.assign({},t,i),n.forEach(n=>n(t,e))}},i=()=>t,a={setState:r,getState:i,getInitialState:()=>o,subscribe:e=>(n.add(e),()=>n.delete(e))},o=t=e(r,i,a);return a},o=(e=>e?a(e):a),s=e=>e;function c(e,t=s){let r=n.useSyncExternalStore(e.subscribe,n.useCallback(()=>t(e.getState()),[e,t]),n.useCallback(()=>t(e.getInitialState()),[e,t]));return n.useDebugValue(r),r}var l=e=>{let t=o(e),n=e=>c(t,e);return Object.assign(n,t),n},u=(e=>e?l(e):l);function d(e,t){let n;try{n=e()}catch{return}return{getItem:e=>{let r=e=>e===null?null:JSON.parse(e,t?.reviver),i=n.getItem(e)??null;return i instanceof Promise?i.then(r):r(i)},setItem:(e,r)=>n.setItem(e,JSON.stringify(r,t?.replacer)),removeItem:e=>n.removeItem(e)}}var f=e=>t=>{try{let n=e(t);return n instanceof Promise?n:{then(e){return f(e)(n)},catch(e){return this}}}catch(e){return{then(e){return this},catch(t){return f(t)(e)}}}},p=(e,t)=>(n,r,i)=>{let a={storage:d(()=>window.localStorage),partialize:e=>e,version:0,merge:(e,t)=>({...t,...e}),...t},o=!1,s=0,c=new Set,l=new Set,u=a.storage;if(!u)return e((...e)=>{console.warn(`[zustand persist middleware] Unable to update item '${a.name}', the given storage is currently unavailable.`),n(...e)},r,i);let p=()=>{let e=a.partialize({...r()});return u.setItem(a.name,{state:e,version:a.version})},m=i.setState;i.setState=(e,t)=>(m(e,t),p());let h=e((...e)=>(n(...e),p()),r,i);i.getInitialState=()=>h;let g,_=()=>{if(!u)return;let e=++s;o=!1,c.forEach(e=>e(r()??h));let t=a.onRehydrateStorage?.call(a,r()??h)||void 0;return f(u.getItem.bind(u))(a.name).then(e=>{if(e){if(typeof e.version==`number`&&e.version!==a.version){if(a.migrate){let t=a.migrate(e.state,e.version);return t instanceof Promise?t.then(e=>[!0,e]):[!0,t]}console.error(`State loaded from storage couldn't be migrated since no migrate function was provided`)}else return[!1,e.state]}return[!1,void 0]}).then(t=>{if(e!==s)return;let[i,o]=t;if(g=a.merge(o,r()??h),n(g,!0),i)return p()}).then(()=>{e===s&&(t?.(r(),void 0),g=r(),o=!0,l.forEach(e=>e(g)))}).catch(n=>{e===s&&t?.(void 0,n)})};return i.persist={setOptions:e=>{a={...a,...e},e.storage&&(u=e.storage)},clearStorage:()=>{++s,u?.removeItem(a.name)},getOptions:()=>a,rehydrate:()=>_(),hasHydrated:()=>o,onHydrate:e=>(c.add(e),()=>{c.delete(e)}),onFinishHydration:e=>(l.add(e),()=>{l.delete(e)})},a.skipHydration||_(),g||h},m={ink:{label:`Ink night`,colors:{editorBg:`#161513`,editorFg:`#f0ede6`,editorGutter:`#6f6b64`,editorSelection:`#3a474f`,editorLine:`#1f1e1b`,editorBlock:`rgba(184, 196, 206, 0.07)`,editorGuide:`rgba(240, 237, 230, 0.12)`,editorCursor:`#b8c4ce`,editorComment:`#8a857c`,editorKeyword:`#b8c4ce`,editorString:`#9db5a4`,editorNumber:`#d4c4a8`,editorFunction:`#e4ddd0`,terminalBg:`#0e0e0c`,terminalFg:`#dcd6cc`,terminalErr:`#e08b84`,terminalPrompt:`#b8c4ce`}},paper:{label:`Paper`,colors:{editorBg:`#f7f4ec`,editorFg:`#1c1b18`,editorGutter:`#8a857c`,editorSelection:`#d5dde3`,editorLine:`#efebe1`,editorBlock:`rgba(61, 74, 85, 0.06)`,editorGuide:`rgba(28, 27, 24, 0.12)`,editorCursor:`#3d4a55`,editorComment:`#7a756c`,editorKeyword:`#3d4a55`,editorString:`#3f6b52`,editorNumber:`#7a5a2e`,editorFunction:`#1c1b18`,terminalBg:`#ece8de`,terminalFg:`#1c1b18`,terminalErr:`#9b3d36`,terminalPrompt:`#3d4a55`}},forest:{label:`Forest`,colors:{editorBg:`#121613`,editorFg:`#e4ece4`,editorGutter:`#6d7a6f`,editorSelection:`#2c3a30`,editorLine:`#181e1a`,editorBlock:`rgba(125, 154, 126, 0.1)`,editorGuide:`rgba(228, 236, 228, 0.12)`,editorCursor:`#9db5a4`,editorComment:`#7d8a80`,editorKeyword:`#9db5a4`,editorString:`#c4d4b8`,editorNumber:`#d4c4a8`,editorFunction:`#e4ece4`,terminalBg:`#0c100d`,terminalFg:`#d5e0d6`,terminalErr:`#e08b84`,terminalPrompt:`#9db5a4`}},contrast:{label:`High contrast`,colors:{editorBg:`#000000`,editorFg:`#ffffff`,editorGutter:`#a3a3a3`,editorSelection:`#335577`,editorLine:`#141414`,editorBlock:`rgba(255, 255, 255, 0.06)`,editorGuide:`rgba(255, 255, 255, 0.22)`,editorCursor:`#ffffff`,editorComment:`#b0b0b0`,editorKeyword:`#dce6f0`,editorString:`#cde8d2`,editorNumber:`#f0e6c8`,editorFunction:`#ffffff`,terminalBg:`#000000`,terminalFg:`#ffffff`,terminalErr:`#ff8a80`,terminalPrompt:`#dce6f0`}}},h=[{id:`IBM Plex Mono`,label:`IBM Plex Mono`},{id:`JetBrains Mono`,label:`JetBrains Mono`},{id:`Fira Code`,label:`Fira Code`},{id:`Source Code Pro`,label:`Source Code Pro`},{id:`ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace`,label:`System mono`}],g={...m.ink.colors,preset:`ink`,fontFamily:`IBM Plex Mono`,fontSize:14,fontWeight:`400`,fontStyle:`normal`,tabSize:4,wordWrap:!0,showBlockLines:!0,volumeCursor:!0},_=0,v=u()(p(e=>({hydrated:!1,hasUsed:!1,code:r,stdin:``,replDraft:``,settings:g,terminalLayout:`below`,screen:`editor`,status:`idle`,statusDetail:``,pythonVersion:`Python 3.14`,lines:[],diagnostics:[],lastError:null,cursor:{line:1,column:1},persistGranted:!1,setHydrated:()=>e({hydrated:!0}),setCode:t=>e({code:t,hasUsed:!0}),setStdin:t=>e({stdin:t}),setReplDraft:t=>e({replDraft:t}),patchSettings:t=>e(e=>({settings:{...e.settings,...t}})),applyPreset:t=>e(e=>({settings:{...e.settings,...m[t].colors,preset:t}})),setTerminalLayout:t=>e(e=>({terminalLayout:t,screen:t===`screen`&&e.screen===`terminal`?`terminal`:`editor`})),setScreen:t=>e({screen:t}),setStatus:(t,n=``)=>e({status:t,statusDetail:n}),setPythonVersion:t=>e({pythonVersion:t}),appendLine:t=>e(e=>({lines:[...e.lines,{...t,id:`l${++_}`}].slice(-400)})),clearTerminal:()=>e({lines:[],lastError:null}),setDiagnostics:t=>e({diagnostics:t}),setLastError:t=>e({lastError:t}),setCursor:(t,n)=>e({cursor:{line:t,column:n}}),setPersistGranted:t=>e({persistGranted:t}),resetSettings:()=>e({settings:g,terminalLayout:`below`}),newFile:()=>e({code:``,hasUsed:!0,lastError:null})}),{name:`zhina-python`,storage:d(()=>localStorage),skipHydration:!0,partialize:e=>({code:e.code,stdin:e.stdin,settings:e.settings,terminalLayout:e.terminalLayout,hasUsed:e.hasUsed})}));export{i,h as n,m as r,v as t};