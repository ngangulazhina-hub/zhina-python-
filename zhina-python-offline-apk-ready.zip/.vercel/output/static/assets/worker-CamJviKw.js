(function(){let e=`https://cdn.jsdelivr.net/pyodide/v314.0.7/full/`,t=null,n=[],r=null;function i(e){self.postMessage(e)}async function a(){return t||(i({type:`status`,status:`loading`}),t=await(await import(e+`pyodide.mjs`)).loadPyodide({indexURL:e}),t.setStdout({batched:e=>i({type:`stdout`,text:e})}),t.setStderr({batched:e=>i({type:`stderr`,text:e})}),t.setStdin({stdin:()=>{if(!n.length)return null;let e=n.shift()??``;return e.endsWith(`
`)?e:`${e}\n`}}),await t.runPythonAsync(`
import sys, os
os.environ.setdefault("MPLBACKEND", "AGG")
sys.ps1 = ">>> "
sys.ps2 = "... "
`),i({type:`ready`,version:await o()}),t)}async function o(){if(!t)return`Python`;let e=await t.runPythonAsync(`import sys; sys.version.split()[0]`);return`Python ${String(e)}`}async function s(e,t,o){let s=await a();n=t.split(/\r?\n/),n.length&&n[n.length-1]===``&&n.pop(),i({type:`status`,status:`running`});try{await s.loadPackagesFromImports(e)}catch(e){i({type:`stderr`,text:`Package load: ${String(e)}\n`})}try{(o===`run`||!r)&&(r=s.runPython(`{'__name__': '__main__'}`));let t=await s.runPythonAsync(e,{globals:r});if(o===`repl`&&t!=null){let e=String(t);e&&e!==`None`&&i({type:`stdout`,text:`${e}\n`})}await c(s),i({type:`done`,ok:!0})}catch(e){i({type:`python-error`,text:l(e)}),i({type:`done`,ok:!1})}finally{i({type:`status`,status:`ready`})}}async function c(e){try{let t=await e.runPythonAsync(`
def _zhina_capture_figs():
    import sys
    if "matplotlib" not in sys.modules:
        return []
    import matplotlib.pyplot as plt
    import io, base64
    out = []
    for num in list(plt.get_fignums()):
        fig = plt.figure(num)
        buf = io.BytesIO()
        fig.savefig(buf, format="png", dpi=140, bbox_inches="tight", facecolor="white")
        out.append(base64.b64encode(buf.getvalue()).decode("ascii"))
    plt.close("all")
    return out

_zhina_capture_figs()`),n=[];if(Array.isArray(t))n=t;else if(t&&typeof t.toJs==`function`){let e=t.toJs();n=Array.isArray(e)?e:[]}for(let e of n)i({type:`image`,data:String(e)})}catch{}}function l(e){if(e&&typeof e==`object`){let t=e;return t.message||t.toString?.()||String(e)}return String(e)}async function u(e){let t=await a();try{t.globals.set(`_zhina_src`,e);let n=await t.runPythonAsync(`
import ast, json, builtins, sys

def _zhina_analyze(src):
    out = []
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        out.append({
            "from": 0,
            "to": 0,
            "line": int(e.lineno or 1),
            "column": int(e.offset or 1),
            "severity": "error",
            "type": type(e).__name__,
            "message": e.msg or "invalid syntax",
        })
        return json.dumps(out)

    assigned = set()
    imported = []
    used = set()

    class V(ast.NodeVisitor):
        def visit_FunctionDef(self, node):
            assigned.add(node.name)
            self.generic_visit(node)
        def visit_AsyncFunctionDef(self, node):
            assigned.add(node.name)
            self.generic_visit(node)
        def visit_ClassDef(self, node):
            assigned.add(node.name)
            self.generic_visit(node)
        def visit_Assign(self, node):
            for t in node.targets:
                if isinstance(t, ast.Name):
                    assigned.add(t.id)
            self.generic_visit(node)
        def visit_AnnAssign(self, node):
            if isinstance(node.target, ast.Name):
                assigned.add(node.target.id)
            self.generic_visit(node)
        def visit_Import(self, node):
            for a in node.names:
                imported.append((a.asname or a.name.split(".")[0], node.lineno, a.name))
            self.generic_visit(node)
        def visit_ImportFrom(self, node):
            for a in node.names:
                if a.name == "*":
                    continue
                imported.append((a.asname or a.name, node.lineno, a.name))
            self.generic_visit(node)
        def visit_Name(self, node):
            if isinstance(node.ctx, ast.Load):
                used.add(node.id)
            self.generic_visit(node)

    V().visit(tree)
    builtin = set(dir(builtins))
    for name, lineno, raw in imported:
        if name not in used:
            out.append({
                "from": 0,
                "to": 0,
                "line": int(lineno),
                "column": 1,
                "severity": "warning",
                "type": "UnusedImport",
                "message": f"Imported '{raw}' is never used",
            })
    return json.dumps(out)

_zhina_analyze(_zhina_src)`);i({type:`analysis`,diagnostics:JSON.parse(String(n))})}catch{i({type:`analysis`,diagnostics:[]})}}async function d(e){let t=await a();i({type:`status`,status:`loading`,detail:`Installing ${e}`});try{await t.loadPackage(`micropip`),t.globals.set(`_zhina_pkg`,e),await t.runPythonAsync(`
import micropip
await micropip.install(_zhina_pkg)
`),i({type:`installed`,name:e,ok:!0})}catch(n){try{await t.loadPackage(e),i({type:`installed`,name:e,ok:!0})}catch(t){i({type:`installed`,name:e,ok:!1,message:l(t??n)})}}finally{i({type:`status`,status:`ready`})}}let f=Promise.resolve();self.onmessage=e=>{let t=e.data;f=f.then(async()=>{try{t.type===`init`?await a():t.type===`run`?await s(t.code??``,t.stdin??``,`run`):t.type===`repl`?await s(t.code??``,t.stdin??``,`repl`):t.type===`analyze`?await u(t.code??``):t.type===`install`&&await d(t.name??``)}catch(e){i({type:`fatal`,text:l(e)})}})}})();