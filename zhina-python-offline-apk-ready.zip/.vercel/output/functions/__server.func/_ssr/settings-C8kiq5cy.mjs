import { i as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as useIdeStore } from "./store-CnOKkELU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-C8kiq5cy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SettingsRedirect() {
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		useIdeStore.getState().setScreen("settings");
		navigate({ to: "/" });
	}, [navigate]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex h-dvh items-center justify-center bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Opening settings"
		})
	});
}
//#endregion
export { SettingsRedirect as component };
