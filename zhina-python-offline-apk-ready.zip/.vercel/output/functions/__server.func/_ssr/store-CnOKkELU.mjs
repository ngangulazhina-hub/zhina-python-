import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-CnOKkELU.js
var WELCOME_CODE = `# Welcome to Zhina Python
# A real Python interpreter that runs on this device.
# Press the Run button in the lower right to try it.

def greet(name: str) -> str:
    return f"Hello, {name} — welcome to Zhina."


print(greet("friend"))
print()

# Change the range, then run again.
for n in range(1, 6):
    print(f"{n} × {n} = {n * n}")

print()
print("Tips")
print("- Block lines follow indentation")
print("- Open Settings to change fonts and colours")
print("- Put the terminal on its own screen if you prefer")
`;
var EXAMPLES = [
	{
		id: "welcome",
		title: "Welcome",
		code: WELCOME_CODE
	},
	{
		id: "functions",
		title: "Functions",
		code: `def factorial(n: int) -> int:
    if n < 0:
        raise ValueError("n must be >= 0")
    result = 1
    for k in range(2, n + 1):
        result *= k
    return result


def describe(n: int) -> str:
    return f"{n}! = {factorial(n)}"


for value in (0, 1, 5, 8):
    print(describe(value))
`
	},
	{
		id: "errors",
		title: "Error reporting",
		code: `# Run this file to see how Zhina names the error and the line.
# Then fix it and run again.

def area(width, height):
    return width * height


print("3 × 4 =", area(3, 4))
print("10 × ? =", area(10, height))
`
	},
	{
		id: "input",
		title: "Reading input",
		code: `# Type answers in the Program input box (terminal), one line each,
# then press Run.

name = input("Your name: ")
times = int(input("How many times? "))

for i in range(times):
    print(f"{i + 1}. Nice to meet you, {name}.")
`
	},
	{
		id: "data",
		title: "Lists and dicts",
		code: `scores = {"Ada": 18, "Lin": 21, "Grace": 19}

print("Roster")
for name, score in sorted(scores.items()):
    bar = "■" * score
    print(f"  {name:8} {score:2}  {bar}")

average = sum(scores.values()) / len(scores)
print()
print(f"Average: {average:.1f}")
print("Top:", max(scores, key=scores.get))
`
	},
	{
		id: "chart",
		title: "Chart (matplotlib)",
		code: `import matplotlib.pyplot as plt

xs = list(range(0, 11))
ys = [x * x for x in xs]

fig, ax = plt.subplots(figsize=(6, 3.4))
ax.plot(xs, ys, color="#3d4a55", marker="o")
ax.set_title("Squares")
ax.set_xlabel("n")
ax.set_ylabel("n²")
ax.grid(True, alpha=0.3)
fig.tight_layout()
print("Chart drawn below.")
`
	}
];
var THEME_PRESETS = {
	ink: {
		label: "Ink night",
		colors: {
			editorBg: "#161513",
			editorFg: "#f0ede6",
			editorGutter: "#6f6b64",
			editorSelection: "#3a474f",
			editorLine: "#1f1e1b",
			editorBlock: "rgba(184, 196, 206, 0.07)",
			editorGuide: "rgba(240, 237, 230, 0.12)",
			editorCursor: "#b8c4ce",
			editorComment: "#8a857c",
			editorKeyword: "#b8c4ce",
			editorString: "#9db5a4",
			editorNumber: "#d4c4a8",
			editorFunction: "#e4ddd0",
			terminalBg: "#0e0e0c",
			terminalFg: "#dcd6cc",
			terminalErr: "#e08b84",
			terminalPrompt: "#b8c4ce"
		}
	},
	paper: {
		label: "Paper",
		colors: {
			editorBg: "#f7f4ec",
			editorFg: "#1c1b18",
			editorGutter: "#8a857c",
			editorSelection: "#d5dde3",
			editorLine: "#efebe1",
			editorBlock: "rgba(61, 74, 85, 0.06)",
			editorGuide: "rgba(28, 27, 24, 0.12)",
			editorCursor: "#3d4a55",
			editorComment: "#7a756c",
			editorKeyword: "#3d4a55",
			editorString: "#3f6b52",
			editorNumber: "#7a5a2e",
			editorFunction: "#1c1b18",
			terminalBg: "#ece8de",
			terminalFg: "#1c1b18",
			terminalErr: "#9b3d36",
			terminalPrompt: "#3d4a55"
		}
	},
	forest: {
		label: "Forest",
		colors: {
			editorBg: "#121613",
			editorFg: "#e4ece4",
			editorGutter: "#6d7a6f",
			editorSelection: "#2c3a30",
			editorLine: "#181e1a",
			editorBlock: "rgba(125, 154, 126, 0.1)",
			editorGuide: "rgba(228, 236, 228, 0.12)",
			editorCursor: "#9db5a4",
			editorComment: "#7d8a80",
			editorKeyword: "#9db5a4",
			editorString: "#c4d4b8",
			editorNumber: "#d4c4a8",
			editorFunction: "#e4ece4",
			terminalBg: "#0c100d",
			terminalFg: "#d5e0d6",
			terminalErr: "#e08b84",
			terminalPrompt: "#9db5a4"
		}
	},
	contrast: {
		label: "High contrast",
		colors: {
			editorBg: "#000000",
			editorFg: "#ffffff",
			editorGutter: "#a3a3a3",
			editorSelection: "#335577",
			editorLine: "#141414",
			editorBlock: "rgba(255, 255, 255, 0.06)",
			editorGuide: "rgba(255, 255, 255, 0.22)",
			editorCursor: "#ffffff",
			editorComment: "#b0b0b0",
			editorKeyword: "#dce6f0",
			editorString: "#cde8d2",
			editorNumber: "#f0e6c8",
			editorFunction: "#ffffff",
			terminalBg: "#000000",
			terminalFg: "#ffffff",
			terminalErr: "#ff8a80",
			terminalPrompt: "#dce6f0"
		}
	}
};
var FONT_FAMILIES = [
	{
		id: "IBM Plex Mono",
		label: "IBM Plex Mono"
	},
	{
		id: "JetBrains Mono",
		label: "JetBrains Mono"
	},
	{
		id: "Fira Code",
		label: "Fira Code"
	},
	{
		id: "Source Code Pro",
		label: "Source Code Pro"
	},
	{
		id: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
		label: "System mono"
	}
];
var DEFAULT_SETTINGS = {
	...THEME_PRESETS.ink.colors,
	preset: "ink",
	fontFamily: "IBM Plex Mono",
	fontSize: 14,
	fontWeight: "400",
	fontStyle: "normal",
	tabSize: 4,
	wordWrap: true,
	showBlockLines: true,
	volumeCursor: true
};
var lineSeq = 0;
var useIdeStore = create()(persist((set) => ({
	hydrated: false,
	hasUsed: false,
	code: WELCOME_CODE,
	stdin: "",
	replDraft: "",
	settings: DEFAULT_SETTINGS,
	terminalLayout: "below",
	screen: "editor",
	status: "idle",
	statusDetail: "",
	pythonVersion: "Python 3.14",
	lines: [],
	diagnostics: [],
	lastError: null,
	cursor: {
		line: 1,
		column: 1
	},
	persistGranted: false,
	setHydrated: () => set({ hydrated: true }),
	setCode: (code) => set({
		code,
		hasUsed: true
	}),
	setStdin: (stdin) => set({ stdin }),
	setReplDraft: (replDraft) => set({ replDraft }),
	patchSettings: (patch) => set((s) => ({ settings: {
		...s.settings,
		...patch
	} })),
	applyPreset: (preset) => set((s) => ({ settings: {
		...s.settings,
		...THEME_PRESETS[preset].colors,
		preset
	} })),
	setTerminalLayout: (terminalLayout) => set((s) => ({
		terminalLayout,
		screen: terminalLayout === "screen" && s.screen === "terminal" ? "terminal" : "editor"
	})),
	setScreen: (screen) => set({ screen }),
	setStatus: (status, statusDetail = "") => set({
		status,
		statusDetail
	}),
	setPythonVersion: (pythonVersion) => set({ pythonVersion }),
	appendLine: (line) => set((s) => ({ lines: [...s.lines, {
		...line,
		id: `l${++lineSeq}`
	}].slice(-400) })),
	clearTerminal: () => set({
		lines: [],
		lastError: null
	}),
	setDiagnostics: (diagnostics) => set({ diagnostics }),
	setLastError: (lastError) => set({ lastError }),
	setCursor: (line, column) => set({ cursor: {
		line,
		column
	} }),
	setPersistGranted: (persistGranted) => set({ persistGranted }),
	resetSettings: () => set({
		settings: DEFAULT_SETTINGS,
		terminalLayout: "below"
	}),
	newFile: () => set({
		code: "",
		hasUsed: true,
		lastError: null
	})
}), {
	name: "zhina-python",
	storage: createJSONStorage(() => localStorage),
	skipHydration: true,
	partialize: (s) => ({
		code: s.code,
		stdin: s.stdin,
		settings: s.settings,
		terminalLayout: s.terminalLayout,
		hasUsed: s.hasUsed
	})
}));
//#endregion
export { useIdeStore as i, FONT_FAMILIES as n, THEME_PRESETS as r, EXAMPLES as t };
