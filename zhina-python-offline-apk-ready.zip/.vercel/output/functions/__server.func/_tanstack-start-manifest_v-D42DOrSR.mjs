//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D42DOrSR.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/settings"],
		preloads: ["/assets/index-vcq64dg8.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-vcq64dg8.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BFdp4ta2.js", "/assets/store-su8SbjtH.js"]
	},
	"/settings": {
		filePath: "/workspace/src/routes/settings.tsx",
		children: void 0,
		preloads: ["/assets/settings-BZLoWyQA.js", "/assets/store-su8SbjtH.js"]
	}
} });
//#endregion
export { tsrStartManifest };
